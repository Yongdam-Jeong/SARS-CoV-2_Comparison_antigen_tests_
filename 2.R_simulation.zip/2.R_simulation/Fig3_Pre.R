install.packages("deSolve")
install.packages("dplyr")
install.packages("bayestestR")
install.packages("psych")

library(deSolve)
library(dplyr)
library(bayestestR) 
library(psych)

set.seed(123)

setwd("~/Desktop/")


#########################################################################################
######################################## Setting ########################################
#########################################################################################
Tmin <- 0
Tmax <- 60
step_size <- 1
mtime <- seq(Tmin,Tmax,step_size)
N <- 10^4 ## # of samples

DLmin <- 2
DLmax <- 7
Step_size <- 0.1

SI <- 6 ## Serial interval

pop <- read.csv("populationParameters_Both.txt", row.names = 1)
All <- read.csv("VL.csv")




########################################################################################################################
##################################### Computing scaling constant of infectiousness #####################################
########################################################################################################################
h <- 0.5471
Km <- 2.72*10^8
R <- 3.0
All$IF <- ((10^(All$V1*h)/(10^(All$V1*h)+Km^h))) + ((10^(All$V2*h)/(10^(All$V2*h)+Km^h)))

Rall <- c()
for (i in 1:N) {
  
  all <- subset(All,All$ID==i)
  Rall[i] <- auc(all$time,all$IF)
  
}
C <- R/mean(Rall)




#####################################################################################
##################################### Schematic #####################################
#####################################################################################
tmin <- 0
tmax <- 20
step_size <- 0.01
stime <- seq(tmin,tmax,step_size)

Covfun<-function(pars){
  
  r <- as.numeric(pars[1])
  d <- as.numeric(pars[2])
  b <- as.numeric(pars[3])
  
  derivs<-function(time,y,pars){
    with(as.list(c(pars,y)),{
      
      dTa<--b*Ta*V
      dV<-r*Ta*V-d*V
      
      return(list(c(dTa,dV)))
    })
  }
  y<-c(Ta=1,V=0.01)
  
  times<-c(seq(tmin,tmax,step_size))
  out<-lsoda(y=y,parms=pars,times=times,func=derivs,rtol=0.00004,atol=0)
  out2<-cbind(time=out[,1],V=((log10(out[,3]))))
  as.data.frame(out2)
}

pop <- read.csv("populationParameters_Both.txt", row.names = 1)

####### Nasal
par1 <- c(r=pop$value[1],delta=pop$value[2],beta=pop$value[3])
Fit1 <- Covfun(par1)

####### Saliva
par2 <- c(r=pop$value[1+3],delta=pop$value[2+3],beta=pop$value[3+3])
Fit2 <- Covfun(par2)

FitI <- data.frame(time=stime,nasal=Fit1$V,saliva=Fit2$V)

Infectiousness <- C* ((10^(FitI$nasal*h)/(10^(FitI$nasal*h)+Km^h)) + (10^(FitI$saliva*h)/(10^(FitI$saliva*h)+Km^h)))
FitI <- cbind(FitI,Infectiousness)

tinc <- round(pop$value[7], digits=0)
FitI$time <- round(FitI$time, digits=2)

FitIpre <- subset(FitI,FitI$time<=tinc)
FitIpre2 <- subset(FitI,FitI$time<=3)




##################################################################################################################
##################################### Screening in the pre-symptomatic phase #####################################
##################################################################################################################
TotalIF <- c()
TotalIF_Nasal <- c()
TotalIF_Saliva <- c()

DL <- 6

All$P1 <- pnorm(DL,mean=All$V1, sd=pop["a1", "value"], lower.tail=FALSE)
All$P2 <- pnorm(DL,mean=All$V2, sd=pop["a2", "value"], lower.tail=FALSE)

for ( i in 1:N ) {
  
  all <- subset(All,All$ID==i)
  all <- subset(all,all$time<=all$IP[1])
  R0  <- C*auc(all$time,all$IF)
  # SI <- all$SI[1]
  
  if (all$IP[1]-SI <= 0 & SI > 0) {
    
    R1 <- 0
    R2 <- 0
    
    for ( j in 1:(all$IP[1]-1) ) {
      
      all2 <- subset(all,all$time<=j)
      
      p1 <- all$P1[all$time==j]
      p2 <- all$P2[all$time==j]
      
      R11 <- C*auc(all2$time,all2$IF)
      R22 <- C*auc(all2$time,all2$IF)
      
      R1 <- R1 + (p1*R11+(1-p1)*R0)
      R2 <- R2 + (p2*R22+(1-p2)*R0)
      
    }
    
    TotalIF[i] <- R0
    TotalIF_Nasal[i]  <- 1/(SI)*((SI-all$IP[1]+1)*R0 + R1)
    TotalIF_Saliva[i] <- 1/(SI)*((SI-all$IP[1]+1)*R0 + R2)
    
  } else if (all$IP[1]-SI > 0 & SI > 0)  {
    
    R1 <- 0
    R2 <- 0
    
    for ( j in (all$IP[1]-SI):(all$IP[1]-1) ) {
      
      all2 <- subset(all,all$time<=j)
      
      p1 <- all$P1[all$time==j]
      p2 <- all$P2[all$time==j]
      
      R11 <- C*auc(all2$time,all2$IF)
      R22 <- C*auc(all2$time,all2$IF)
      
      R1 <- R1 + (p1*R11+(1-p1)*R0)
      R2 <- R2 + (p2*R22+(1-p2)*R0)
      
    }
    
    TotalIF[i] <- R0
    TotalIF_Nasal[i]  <- 1/(SI)*(R1)
    TotalIF_Saliva[i] <- 1/(SI)*(R2)
    
  } else {
    
    TotalIF[i] <- R0
    TotalIF_Nasal[i]  <- R0
    TotalIF_Saliva[i] <- R0
    
  }
  
}


##################################### Arranging results
TotalIF <- data.frame(value=TotalIF,group=rep(0,times=N))
TotalIF_Nasal <- data.frame(value=TotalIF_Nasal,group=rep(1,times=N))
TotalIF_Saliva <- data.frame(value=TotalIF_Saliva,group=rep(2,times=N))


######## 1) Reproduction number
Pre <- data.frame(R0=TotalIF$value,R1=TotalIF_Nasal$value,R2=TotalIF_Saliva$value,ID=seq(1,N,by=1))
write.csv(Pre,"Pre.csv",row.names = FALSE)
Pre <- read.csv("Pre.csv")

Number <- data.frame(value=c(Pre$R0,Pre$R1,Pre$R2),
                     group=rep(c("0","1","2"),each=N))

Number_0 <- subset(Number,group==0)
Number_1 <- subset(Number,group==1)
Number_2 <- subset(Number,group==2)

describeBy(Number$value,Number$group)
bartlett.test(Number$value,Number$group)
summary(aov(Number$value~Number$group))

t.test(Number_0$value - 1, alternative = "less", mu = 0)$p.value
t.test(Number_1$value - 1, alternative = "less", mu = 0)$p.value
t.test(Number_2$value - 1, alternative = "less", mu = 0)$p.value

P0 <- length(which(Number_0$value<=1))/N
P0 - 1.96*sqrt(P0*(1-P0)/N)
P0 + 1.96*sqrt(P0*(1-P0)/N)

P1 <- length(which(Number_1$value<=1))/N
P1 - 1.96*sqrt(P1*(1-P1)/N)
P1 + 1.96*sqrt(P1*(1-P1)/N)

P2 <- length(which(Number_2$value<=1))/N
P2 - 1.96*sqrt(P2*(1-P2)/N)
P2 + 1.96*sqrt(P2*(1-P2)/N)

######## 2) Reduction of transmissibility
Reduction <- data.frame(value=c((Pre$R0-Pre$R1)/Pre$R0*100,(Pre$R0-Pre$R2)/Pre$R0*100),
                        group=rep(c("1","2"),each=N))


######## 3) Risk of transmission
Risk <- data.frame(value=c((1-exp(-Pre$R0))*100,(1-exp(-Pre$R1))*100,(1-exp(-Pre$R2))*100),
                   group=rep(c("0","1","2"),each=N))

describeBy(Risk$value,Risk$group)
bartlett.test(Risk$value,Risk$group)
summary(aov(Risk$value~Risk$group))

Risk_0 <- subset(Risk,group==0)
Risk_1 <- subset(Risk,group==1)
Risk_2 <- subset(Risk,group==2)

mean(Risk_1$value - Risk_2$value); quantile(Risk_1$value - Risk_2$value, c(0.025,0.975))
L <- length(which(Risk_1$value - Risk_2$value>0))/N
L - 1.96*sqrt(L*(1-L)/N)
L + 1.96*sqrt(L*(1-L)/N)
t.test(Risk_1$value - Risk_2$value, alternative = "greater", mu = 0)$p.value


###########################################################################################
##################################### Detection limit #####################################
###########################################################################################
Pre_Nasal  <- matrix(NA,nrow=((DLmax-DLmin)/Step_size+1),ncol=11)
Pre_Saliva <- matrix(NA,nrow=((DLmax-DLmin)/Step_size+1),ncol=11)
Pre_Effect_0N <- matrix(NA,nrow=((DLmax-DLmin)/Step_size+1),ncol=13)
Pre_Effect_0S <- matrix(NA,nrow=((DLmax-DLmin)/Step_size+1),ncol=13)
Pre_Effect_NS <- matrix(NA,nrow=((DLmax-DLmin)/Step_size+1),ncol=13)

for ( k in 1:((DLmax-DLmin)/Step_size+1) ) {
  
  
  ##################################### Probability of positive results
  
  DL <- DLmin + (k-1)*Step_size
  
  All$P1 <- pnorm(DL,mean=All$V1, sd=pop["a1", "value"], lower.tail=FALSE)
  All$P2 <- pnorm(DL,mean=All$V2, sd=pop["a2", "value"], lower.tail=FALSE)
  
  
  ##################################### Self-screening with tests
  
  Pre_N <- c()
  Pre_S <- c()
  
  
  for ( i in 1:N ) {
    
    all <- subset(All,All$ID==i)
    all <- subset(all,all$time<=all$IP[1])
    R0  <- C*auc(all$time,all$IF)
    
    
    if (all$IP[1]-SI <= 0 & SI > 0) {
      
      R1 <- 0
      R2 <- 0
      
      for ( j in 1:(all$IP[1]-1) ) {
        
        all2 <- subset(all,all$time<=j)
        
        p1 <- all$P1[all$time==j]
        p2 <- all$P2[all$time==j]
        
        R11 <- C*auc(all2$time,all2$IF)
        R22 <- C*auc(all2$time,all2$IF)
        
        R1 <- R1 + (p1*(R11)+(1-p1)*(R0))
        R2 <- R2 + (p2*(R22)+(1-p2)*(R0))
        
      }
      
      Pre_N[i] <- 1/SI*((SI-all$IP[1]+1)*(R0) + R1)
      Pre_S[i] <- 1/SI*((SI-all$IP[1]+1)*(R0) + R2)
      
    } else if (all$IP[1]-SI > 0 & SI > 0) {
      
      R1 <- 0
      R2 <- 0
      
      for ( j in (all$IP[1]-SI):(all$IP[1]-1) ) {
        
        all2 <- subset(all,all$time<=j)
        
        p1 <- all$P1[all$time==j]
        p2 <- all$P2[all$time==j]
        
        R11 <- C*auc(all2$time,all2$IF)
        R22 <- C*auc(all2$time,all2$IF)
        
        R1 <- R1 + (p1*(R11)+(1-p1)*(R0))
        R2 <- R2 + (p2*(R22)+(1-p2)*(R0))
        
      }
      
      Pre_N[i] <- 1/SI*(R1)
      Pre_S[i] <- 1/SI*(R2)
      
    } else {
      
      Pre_N[i] <- R0
      Pre_S[i] <- R0
      
    }
    
  }
  
  Pre_Nasal[k,1]  <- DL
  Pre_Saliva[k,1] <- DL
  Pre_Effect_0N[k,1] <- DL
  Pre_Effect_0S[k,1] <- DL
  Pre_Effect_NS[k,1] <- DL
  
  ########### Arranging
  Pre_DL <- data.frame(R0=Pre$R0,R1=Pre_N,R2=Pre_S,ID=seq(1,N,by=1))
  
  R0_0 <- c()
  R0_N <- c()
  R0_S <- c()
  
  R_0 <- c()
  R_N <- c()
  R_S <- c()
  
  r_0 <- c()
  r_N <- c() 
  r_S <- c()
  
  for (l in 1:100) {
    
    pre <- Pre_DL[sample(nrow(Pre_DL), size = 10000, replace = TRUE), ]
    row.names(pre) <- NULL
    
    R0_0[l] <- mean(pre$R0)
    R0_N[l] <- mean(pre$R1)
    R0_S[l] <- mean(pre$R2)
    
    R_0[l] <- mean((pre$R0-pre$R0)/pre$R0*100)
    R_N[l] <- mean((pre$R0-pre$R1)/pre$R0*100)
    R_S[l] <- mean((pre$R0-pre$R2)/pre$R0*100)
    
    r_0[l] <- mean((1-exp(-pre$R0))*100)
    r_N[l] <- mean((1-exp(-pre$R1))*100)
    r_S[l] <- mean((1-exp(-pre$R2))*100)
    
  }
  
  Pre_Nasal[k,2]  <- mean(Pre_N)
  Pre_Nasal[k,3]  <- quantile(R0_N,0.025)
  Pre_Nasal[k,4]  <- quantile(R0_N,0.975)
  Pre_Nasal[k,5]  <- mean((Pre$R0-Pre_N)/Pre$R0*100)
  Pre_Nasal[k,6]  <- quantile(R_N,0.025)
  Pre_Nasal[k,7]  <- quantile(R_N,0.975)
  Pre_Nasal[k,8]  <- mean((1-exp(-Pre_N))*100)
  Pre_Nasal[k,9]  <- quantile(r_N,0.025)
  Pre_Nasal[k,10] <- quantile(r_N,0.975)
  Pre_Nasal[k,11] <- t.test(Pre_N - 1, alternative = "less", mu = 0)$p.value
  
  Pre_Saliva[k,2]  <- mean(Pre_S)
  Pre_Saliva[k,3]  <- quantile(R0_S,0.025)
  Pre_Saliva[k,4]  <- quantile(R0_S,0.975)
  Pre_Saliva[k,5]  <- mean((Pre$R0-Pre_S)/Pre$R0*100)
  Pre_Saliva[k,6]  <- quantile(R_S,0.025)
  Pre_Saliva[k,7]  <- quantile(R_S,0.975)
  Pre_Saliva[k,8]  <- mean((1-exp(-Pre_S))*100)
  Pre_Saliva[k,9]  <- quantile(r_S,0.025)
  Pre_Saliva[k,10] <- quantile(r_S,0.975)
  Pre_Saliva[k,11] <- t.test(Pre_S - 1, alternative = "less", mu = 0)$p.value
  
  Pre_Effect_0N[k,2]  <- mean(R0_0 - R0_N)
  Pre_Effect_0N[k,3]  <- quantile(R0_0 - R0_N,0.025)
  Pre_Effect_0N[k,4]  <- quantile(R0_0 - R0_N,0.975)
  Pre_Effect_0N[k,5]  <- mean(R_0 - R_N)
  Pre_Effect_0N[k,6]  <- quantile(R_0 - R_N,0.025)
  Pre_Effect_0N[k,7]  <- quantile(R_0 - R_N,0.975)
  Pre_Effect_0N[k,8]  <- mean(r_0 - r_N)
  Pre_Effect_0N[k,9]  <- quantile(r_0 - r_N,0.025)
  Pre_Effect_0N[k,10] <- quantile(r_0 - r_N,0.975)
  Pre_Effect_0N[k,11] <- t.test(R0_0 - R0_N, alternative = "greater", mu = 0)$p.value
  Pre_Effect_0N[k,12] <- t.test(R_0 - R_N, alternative = "less", mu = 0)$p.value
  Pre_Effect_0N[k,13] <- t.test(r_0 - r_N, alternative = "greater", mu = 0)$p.value
  
  Pre_Effect_0S[k,2]  <- mean(R0_0 - R0_S)
  Pre_Effect_0S[k,3]  <- quantile(R0_0 - R0_S,0.025)
  Pre_Effect_0S[k,4]  <- quantile(R0_0 - R0_S,0.975)
  Pre_Effect_0S[k,5]  <- mean(R_0 - R_S)
  Pre_Effect_0S[k,6]  <- quantile(R_0 - R_S,0.025)
  Pre_Effect_0S[k,7]  <- quantile(R_0 - R_S,0.975)
  Pre_Effect_0S[k,8]  <- mean(r_0 - r_S)
  Pre_Effect_0S[k,9]  <- quantile(r_0 - r_S,0.025)
  Pre_Effect_0S[k,10] <- quantile(r_0 - r_S,0.975)
  Pre_Effect_0S[k,11] <- t.test(R0_0 - R0_S, alternative = "greater", mu = 0)$p.value
  Pre_Effect_0S[k,12] <- t.test(R_0 - R_S, alternative = "less", mu = 0)$p.value
  Pre_Effect_0S[k,13] <- t.test(r_0 - r_S, alternative = "greater", mu = 0)$p.value
  
  Pre_Effect_NS[k,2]  <- mean(R0_N - R0_S)
  Pre_Effect_NS[k,3]  <- quantile(R0_N - R0_S,0.025)
  Pre_Effect_NS[k,4]  <- quantile(R0_N - R0_S,0.975)
  Pre_Effect_NS[k,5]  <- mean(R_N - R_S)
  Pre_Effect_NS[k,6]  <- quantile(R_N - R_S,0.025)
  Pre_Effect_NS[k,7]  <- quantile(R_N - R_S,0.975)
  Pre_Effect_NS[k,8]  <- mean(r_N - r_S)
  Pre_Effect_NS[k,9]  <- quantile(r_N - r_S,0.025)
  Pre_Effect_NS[k,10] <- quantile(r_N - r_S,0.975)
  Pre_Effect_NS[k,11] <- t.test(R0_N - R0_S, alternative = "greater", mu = 0)$p.value
  Pre_Effect_NS[k,12] <- t.test(R_N - R_S, alternative = "less", mu = 0)$p.value
  Pre_Effect_NS[k,13] <- t.test(r_N - r_S, alternative = "greater", mu = 0)$p.value

}

Pre_Nasal <- data.frame(Pre_Nasal)
Pre_Saliva <- data.frame(Pre_Saliva)
Pre_Effect_0N <- data.frame(Pre_Effect_0N)
Pre_Effect_0S <- data.frame(Pre_Effect_0S)
Pre_Effect_NS <- data.frame(Pre_Effect_NS)

colnames(Pre_Nasal)  <- c("DL","R","Rmin","Rmax","RT","RTmin","RTmax","r","rmin","rmax","unity")
colnames(Pre_Saliva) <- c("DL","R","Rmin","Rmax","RT","RTmin","RTmax","r","rmin","rmax","unity")
colnames(Pre_Effect_0N) <- c("DL","R0D","R0Dmin","R0Dmax","RD","RDmin","RDmax","rD","rDmin","rDmax","R0_test","R_test","r_test")
colnames(Pre_Effect_0S) <- c("DL","R0D","R0Dmin","R0Dmax","RD","RDmin","RDmax","rD","rDmin","rDmax","R0_test","R_test","r_test")
colnames(Pre_Effect_NS) <- c("DL","R0D","R0Dmin","R0Dmax","RD","RDmin","RDmax","rD","rDmin","rDmax","R0_test","R_test","r_test")

write.csv(Pre_Nasal,"Pre_Nasal.csv", row.names = FALSE)
write.csv(Pre_Saliva,"Pre_Saliva.csv", row.names = FALSE)
write.csv(Pre_Effect_0N,"Pre_Effect_0N.csv", row.names = FALSE)
write.csv(Pre_Effect_0S,"Pre_Effect_0S.csv", row.names = FALSE)
write.csv(Pre_Effect_NS,"Pre_Effect_NS.csv", row.names = FALSE)

Pre_Nasal <- read.csv("Pre_Nasal.csv")
Pre_Saliva <- read.csv("Pre_Saliva.csv")
Pre_Effect_0N <- read.csv("Pre_Effect_0N.csv")
Pre_Effect_0S <- read.csv("Pre_Effect_0S.csv")
Pre_Effect_NS <- read.csv("Pre_Effect_NS.csv")



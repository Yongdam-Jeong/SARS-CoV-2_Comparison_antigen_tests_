install.packages("deSolve")
install.packages("dplyr")
install.packages("bayestestR")

library(deSolve)
library(dplyr)
library(bayestestR)


setwd("~/Desktop/")


##################################### Setting
Tmin <- 0
Tmax <- 60
step_size <- 0.1
mtime <- seq(Tmin,Tmax,step_size)
N <- 10^4 ## # of samples

h <- 0.5471
Km <- 2.72*10^8

R0 <- 3.0


##################################### Viral dynamics model
Covfun <- function(pars){
  
  b <- as.numeric(pars[1])
  r <- as.numeric(pars[2])
  d <- as.numeric(pars[3])
  
  derivs <- function(time,y,pars){
    with(as.list(c(pars,y)),{
      
      dTa <- -b*Ta*V
      dV  <- r*Ta*V-d*V
      
      return(list(c(dTa,dV)))
    })
  }
  y<-c(Ta=1,V=0.01)
  
  times<-c(seq(Tmin,Tmax,step_size))
  out<-lsoda(y=y,parms=pars,times=times,func=derivs,rtol=0.00004,atol=0)
  out2<-cbind(time=out[,1],V=(log10(out[,3])))
  as.data.frame(out2)
}


##################################### Computing scaling constant
All <- read.csv("VL.csv")
All$IF <- ((10^(All$V1*h)/(10^(All$V1*h)+Km^h))) + ((10^(All$V2*h)/(10^(All$V2*h)+Km^h)))

Rall <- c()
for (i in 1:N) {

  all <- subset(All,All$ID==i)
  Rall[i] <- auc(all$time,all$IF)

}

C <- R0/mean(Rall)


##################################### Individual
fitall <- read.table("estimatedIndividualParameters_Both.txt", sep = ",", comment.char = "", header = T)

Infectiousness <- data.frame()
Presymptomatic <- c()
Peak <- c()

Rall <- c()
Rpre <- c()
Rsym <- c()

for (i in 1:length(fitall$id)) {
  
  par1 <- c(fitall$b1_mode[i],fitall$r1_mode[i],fitall$d1_mode[i]) ####### Nasal
  Fit1 <- Covfun(par1)
  
  par2 <- c(fitall$b2_mode[i],fitall$r2_mode[i],fitall$d2_mode[i]) ####### Saliva
  Fit2 <- Covfun(par2)
  
  Fit <- data.frame(time=mtime,nasal=Fit1$V,saliva=Fit2$V)
  Transmission <- C*( (10^(Fit$nasal*h))/(10^(Fit$nasal*h)+Km^h) + (10^(Fit$saliva*h))/(10^(Fit$saliva*h)+Km^h) )
  Fit <- cbind(Fit,Transmission)
  
  tinc <- round(fitall$tau_mode[i], digits = 1)
  Fit$time <- round(Fit$time, digits=1)
  Fitpre <- subset(Fit,Fit$time<=tinc)
  
  Secall <- auc(Fit$time,Fit$Transmission)
  Secpre <- auc(Fitpre$time,Fitpre$Transmission)
  Secsym <- auc(Fit$time,Fit$Transmission)-auc(Fitpre$time,Fitpre$Transmission)
  
  Fitpre <- auc(Fitpre$time,Fitpre$Transmission)/auc(Fit$time,Fit$Transmission)
  
  Fit$time <- Fit$time - tinc
  Fit$ID <- rep(i,times=length(Fit$time))
  
  Infectiousness <- rbind(Infectiousness,Fit)
  Presymptomatic[i] <- Fitpre
  Peak[i] <- Fit$time[which.max(Fit$Transmission)]
  
  Rall[i] <- Secall
  Rpre[i] <- Secpre
  Rsym[i] <- Secsym
  
}


##################################### Peak Time & ProPortion
M <- 1000

PT <- c()
PP <- c()

for (j in 1:M) {
  
  peak <- sample(Peak,length(fitall$id),replace=TRUE)
  PT[j] <- mean(peak)
  
  presymptomatic <- sample(Presymptomatic,length(fitall$id),replace=TRUE)
  PP[j] <- mean(presymptomatic)
  
}

mean(PT); quantile(PT,c(0.025,0.975))
mean(PP); quantile(PP,c(0.025,0.975))

Pre  <- data.frame(mean=mean(PP)*100,min=quantile(PP,c(0.025,0.975))[1]*100,max=quantile(PP,c(0.025,0.975))[2]*100)
Post <- data.frame(mean=100-mean(PP)*100,min=100-quantile(PP,c(0.025,0.975))[2]*100,max=100-quantile(PP,c(0.025,0.975))[1]*100)
Proportion <- rbind(Pre,Post)
Proportion$phase <- c(1,2)


install.packages("dplyr")
install.packages("bayestestR")

library(dplyr)
library(bayestestR) 

set.seed(45)

setwd("~/Desktop/")


#########################################################################################
######################################## Setting ########################################
#########################################################################################
Tmin <- 0
Tmax <- 60
step_size <- 1
mtime <- seq(Tmin,Tmax,step_size)
N <- 10^4 ## # of samples

DLmin <- 2
DLmax <- 7
Step_size <- 0.1

SI <- 6 ## Serial interval

pop <- read.csv("populationParameters_Both.txt", row.names = 1)
All <- read.csv("VL.csv")




########################################################################################################################
##################################### Computing scaling constant of infectiousness #####################################
########################################################################################################################
h <- 0.5471
Km <- 2.72*10^8
R <- 3.0
All$IF <- ((10^(All$V1*h)/(10^(All$V1*h)+Km^h))) + ((10^(All$V2*h)/(10^(All$V2*h)+Km^h)))

Rall <- c()
for (i in 1:N) {
  
  all <- subset(All,All$ID==i)
  Rall[i] <- auc(all$time,all$IF)
  
}
C <- R/mean(Rall)




###########################################################################################
##################################### Pre-symptomatic #####################################
###########################################################################################
Pre_Nasal_Heatmap <- data.frame()
Pre_Saliva_Heatmap <- data.frame()

Pre_Nasal_Heatmap_min <- data.frame()
Pre_Saliva_Heatmap_min <- data.frame()

Pre_Nasal_Heatmap_max <- data.frame()
Pre_Saliva_Heatmap_max <- data.frame()

Pre_Effect <- data.frame()

for ( k in 1:(DLmax-DLmin+1) ) {
  
  ##################################### Probability of positive results
  DL <- DLmin + (k-1)
  
  All$P1 <- pnorm(DL,mean=All$V1, sd=pop["a1", "value"], lower.tail=FALSE)
  All$P2 <- pnorm(DL,mean=All$V2, sd=pop["a2", "value"], lower.tail=FALSE)
  
  for ( l in 1:6 ) {
    
    ##################################### Screening interval (Serial interval)
    SI <- 2 + (l-1)
    
    ##################################### Simulation start
    Pre_N <- c()
    Pre_S <- c()
    
    for ( i in 1:N ) {
      
      all <- subset(All,All$ID==i)
      all <- subset(all,all$time<=all$IP[1])
      R0  <- C*auc(all$time,all$IF)
      
      
      if (all$IP[1]-SI <= 0 & SI > 0) {
        
        R1 <- 0
        R2 <- 0
        
        for ( j in 1:(all$IP[1]-1) ) {
          
          all2 <- subset(all,all$time<=j)
          
          p1 <- all$P1[all$time==j]
          p2 <- all$P2[all$time==j]
          
          R11 <- C*auc(all2$time,all2$IF)
          R22 <- C*auc(all2$time,all2$IF)
          
          R1 <- R1 + (p1*(R11)+(1-p1)*(R0))
          R2 <- R2 + (p2*(R22)+(1-p2)*(R0))
          
        }
        
        Pre_N[i] <- 1/SI*((SI-all$IP[1]+1)*(R0) + R1)
        Pre_S[i] <- 1/SI*((SI-all$IP[1]+1)*(R0) + R2)
        
      } else if (all$IP[1]-SI > 0 & SI > 0) {
        
        R1 <- 0
        R2 <- 0
        
        for ( j in (all$IP[1]-SI):(all$IP[1]-1) ) {
          
          all2 <- subset(all,all$time<=j)
          
          p1 <- all$P1[all$time==j]
          p2 <- all$P2[all$time==j]
          
          R11 <- C*auc(all2$time,all2$IF)
          R22 <- C*auc(all2$time,all2$IF)
          
          R1 <- R1 + (p1*(R11)+(1-p1)*(R0))
          R2 <- R2 + (p2*(R22)+(1-p2)*(R0))
          
        }
        
        Pre_N[i] <- 1/SI*(R1)
        Pre_S[i] <- 1/SI*(R2)
        
      } else {
        
        Pre_N[i] <- R0
        Pre_S[i] <- R0
        
      }
      
    }
    
    Pre_DL <- data.frame(R1=Pre_N,R2=Pre_S,ID=seq(1,N,by=1))
    
    R0_N <- c()
    R0_S <- c()
    
    r_N <- c() 
    r_S <- c()
    
    for (m in 1:100) {
      
      pre <- Pre_DL[sample(nrow(Pre_DL), size = N, replace = TRUE), ]
      row.names(pre) <- NULL
      
      R0_N[m] <- mean(pre$R1)
      R0_S[m] <- mean(pre$R2)
      
      r_N[m] <- mean((1-exp(-pre$R1))*100)
      r_S[m] <- mean((1-exp(-pre$R2))*100)
      
    }
    
    ########### Mean
    Pre_N <- data.frame(value=Pre_N)
    Pre_S <- data.frame(value=Pre_S)
    
    Nasal  <- c(DL,SI,mean(Pre_N$value),mean((1-exp(-Pre_N$value))*100))
    Saliva <- c(DL,SI,mean(Pre_S$value),mean((1-exp(-Pre_S$value))*100))
    
    Pre_Nasal_Heatmap  <- rbind(Pre_Nasal_Heatmap,Nasal)
    Pre_Saliva_Heatmap <- rbind(Pre_Saliva_Heatmap,Saliva)
    
    ########### Min (2.5th percentile)
    Nasal_min  <- c(DL,SI,quantile(R0_N,0.025),quantile(r_N,0.025))
    Saliva_min <- c(DL,SI,quantile(R0_S,0.025),quantile(r_S,0.025))
    
    Pre_Nasal_Heatmap_min  <- rbind(Pre_Nasal_Heatmap_min,Nasal_min)
    Pre_Saliva_Heatmap_min <- rbind(Pre_Saliva_Heatmap_min,Saliva_min)
    
    ########### Max (97.5th percentile)
    Nasal_max  <- c(DL,SI,quantile(R0_N,0.975),quantile(r_N,0.975))
    Saliva_max <- c(DL,SI,quantile(R0_S,0.975),quantile(r_S,0.975))
    
    Pre_Nasal_Heatmap_max  <- rbind(Pre_Nasal_Heatmap_max,Nasal_max)
    Pre_Saliva_Heatmap_max <- rbind(Pre_Saliva_Heatmap_max,Saliva_max)
    
    ########### Effect
    Effect <- c(DL,SI,mean(r_N-r_S),quantile(r_N-r_S,0.025),quantile(r_N-r_S,0.975),t.test(r_N-r_S, alternative = "greater", mu = 0)$p.value)
    Pre_Effect <- rbind(Pre_Effect,Effect)
    
  }
  
}

colnames(Pre_Nasal_Heatmap)  <- c("DL","SI","R0","r")
colnames(Pre_Saliva_Heatmap) <- c("DL","SI","R0","r")

colnames(Pre_Nasal_Heatmap_min)  <- c("DL","SI","R0","r")
colnames(Pre_Saliva_Heatmap_min) <- c("DL","SI","R0","r")

colnames(Pre_Nasal_Heatmap_max)  <- c("DL","SI","R0","r")
colnames(Pre_Saliva_Heatmap_max) <- c("DL","SI","R0","r")

colnames(Pre_Effect) <- c("DL","SI","rD","rDmin","rDmax","r_test")


write.csv(Pre_Nasal_Heatmap,"Pre_Nasal_Heatmap.csv", row.names = FALSE)
write.csv(Pre_Saliva_Heatmap,"Pre_Saliva_Heatmap.csv", row.names = FALSE)

write.csv(Pre_Nasal_Heatmap_min,"Pre_Nasal_Heatmap_min.csv", row.names = FALSE)
write.csv(Pre_Saliva_Heatmap_min,"Pre_Saliva_Heatmap_min.csv", row.names = FALSE)

write.csv(Pre_Nasal_Heatmap_max,"Pre_Nasal_Heatmap_max.csv", row.names = FALSE)
write.csv(Pre_Saliva_Heatmap_max,"Pre_Saliva_Heatmap_max.csv", row.names = FALSE)

write.csv(Pre_Effect_Heatmap,"Pre_Effect_Heatmap.csv", row.names = FALSE)

Pre_Nasal_Heatmap <- read.csv("Pre_Nasal_Heatmap.csv")
Pre_Saliva_Heatmap <- read.csv("Pre_Saliva_Heatmap.csv")




############################################################################################
##################################### Post-symptomatic #####################################
############################################################################################
Post_Nasal_Heatmap <- data.frame()
Post_Saliva_Heatmap <- data.frame()

Post_Nasal_Heatmap_min <- data.frame()
Post_Saliva_Heatmap_min <- data.frame()

Post_Nasal_Heatmap_max <- data.frame()
Post_Saliva_Heatmap_max <- data.frame()

Post_Effect <- data.frame()

for ( k in 1:(DLmax-DLmin+1) ) {
  
  ##################################### Probability of positive results
  DL <- DLmin + (k-1)
  
  All$P1 <- pnorm(DL,mean=All$V1, sd=pop["a1", "value"], lower.tail=FALSE)
  All$P2 <- pnorm(DL,mean=All$V2, sd=pop["a2", "value"], lower.tail=FALSE)
  
  for ( l in 1:6 ) {
 
    ##################################### Isolation period
    IP <- 5 + (l-1)
    
    ##################################### Simulation start
    Post_N <- c()
    Post_S <- c()
    
    Post_N_IP <- c()
    Post_S_IP <- c()
    
    for ( i in 1:N ) {
      
      all <- subset(All,All$ID==i)
      all <- subset(all,all$time>=all$IP[1])
      R0  <- C*auc(all$time,all$IF)
      
      ####### Infectiousness for each time (time >= 2)
      all2 <- subset(all,all$time>=all$IP[1]+2)
      all3 <- subset(all,all$time>=all$IP[1]+3)
      all4 <- subset(all,all$time>=all$IP[1]+4)
      all5 <- subset(all,all$time>=all$IP[1]+5)
      all6 <- subset(all,all$time>=all$IP[1]+6)
      all7 <- subset(all,all$time>=all$IP[1]+7)
      all8 <- subset(all,all$time>=all$IP[1]+8)
      all9 <- subset(all,all$time>=all$IP[1]+9)
      all10 <- subset(all,all$time>=all$IP[1]+10)
      
      R02 <- C*auc(all2$time,all2$IF)
      R03 <- C*auc(all3$time,all3$IF)
      R04 <- C*auc(all4$time,all4$IF)
      R05 <- C*auc(all5$time,all5$IF)
      R06 <- C*auc(all6$time,all6$IF)
      R07 <- C*auc(all7$time,all7$IF)
      R08 <- C*auc(all8$time,all8$IF)
      R09 <- C*auc(all9$time,all9$IF)
      R010 <- C*auc(all10$time,all10$IF)
      
      
      ####### Probability of detection for each time since symptom onset
      ## Nasal
      p0_1 <- 1
      p1_1 <- all$P1[all$time==all$IP[1]+1]
      p2_1 <- all$P1[all$time==all$IP[1]+2]
      p3_1 <- all$P1[all$time==all$IP[1]+3]
      p4_1 <- all$P1[all$time==all$IP[1]+4]
      p5_1 <- all$P1[all$time==all$IP[1]+5]
      p6_1 <- all$P1[all$time==all$IP[1]+6]
      p7_1 <- all$P1[all$time==all$IP[1]+7]
      p8_1 <- all$P1[all$time==all$IP[1]+8]
      p9_1 <- all$P1[all$time==all$IP[1]+9]
      p10_1 <- all$P1[all$time==all$IP[1]+10]
      
      ## Saliva
      p0_2 <- 1
      p1_2 <- all$P2[all$time==all$IP[1]+1]
      p2_2 <- all$P2[all$time==all$IP[1]+2]
      p3_2 <- all$P2[all$time==all$IP[1]+3]
      p4_2 <- all$P2[all$time==all$IP[1]+4]
      p5_2 <- all$P2[all$time==all$IP[1]+5]
      p6_2 <- all$P2[all$time==all$IP[1]+6]
      p7_2 <- all$P2[all$time==all$IP[1]+7]
      p8_2 <- all$P2[all$time==all$IP[1]+8]
      p9_2 <- all$P2[all$time==all$IP[1]+9]
      p10_2 <- all$P2[all$time==all$IP[1]+10]
      
      
      ####### Coefficients of probability for each infectiousness (time >= 2)
      ## Nasal
      C2_1 <- (1-p1_1)*(1-p2_1) 
      C3_1 <- p1_1*(1-p2_1)*(1-p3_1)
      C4_1 <- p2_1*(1-p3_1)*(1-p4_1)
      C5_1 <- (1-C2_1) * p3_1*(1-p4_1)*(1-p5_1)
      C6_1 <- (1-(C2_1+C3_1)) * p4_1*(1-p5_1)*(1-p6_1)
      C7_1 <- (1-(C2_1+C3_1+C4_1)) * p5_1*(1-p6_1)*(1-p7_1)
      C8_1 <- (1-(C2_1+C3_1+C4_1+C5_1)) * p6_1*(1-p7_1)*(1-p8_1)
      C9_1 <- (1-(C2_1+C3_1+C4_1+C5_1+C6_1)) * p7_1*(1-p8_1)*(1-p9_1)
      C10_1 <- (1-(C2_1+C3_1+C4_1+C5_1+C6_1+C7_1)) * p8_1*(1-p9_1)*(1-p10_1)
      
      
      ## Saliva
      C2_2 <- (1-p1_2)*(1-p2_2) 
      C3_2 <- p1_2*(1-p2_2)*(1-p3_2)
      C4_2 <- p2_2*(1-p3_2)*(1-p4_2)
      C5_2 <- (1-C2_2) * p3_2*(1-p4_2)*(1-p5_2)
      C6_2 <- (1-(C2_2+C3_2)) * p4_2*(1-p5_2)*(1-p6_2)
      C7_2 <- (1-(C2_2+C3_2+C4_2)) * p5_2*(1-p6_2)*(1-p7_2)
      C8_2 <- (1-(C2_2+C3_2+C4_2+C5_2)) * p6_2*(1-p7_2)*(1-p8_2)
      C9_2 <- (1-(C2_2+C3_2+C4_2+C5_2+C6_2)) * p7_2*(1-p8_2)*(1-p9_2)
      C10_2 <- (1-(C2_2+C3_2+C4_2+C5_2+C6_2+C7_2)) * p8_2*(1-p9_2)*(1-p10_2)
      
      
      ####### Total Coefficients
      ## Nasal
      TC5_1  <- C2_1 + C3_1 + C4_1
      TC6_1  <- C2_1 + C3_1 + C4_1 + C5_1
      TC7_1  <- C2_1 + C3_1 + C4_1 + C5_1 + C6_1
      TC8_1  <- C2_1 + C3_1 + C4_1 + C5_1 + C6_1 + C7_1
      TC9_1  <- C2_1 + C3_1 + C4_1 + C5_1 + C6_1 + C7_1 + C8_1
      TC10_1 <- C2_1 + C3_1 + C4_1 + C5_1 + C6_1 + C7_1 + C8_1 + C9_1
      
      ## Saliva
      TC5_2  <- C2_2 + C3_2 + C4_2
      TC6_2  <- C2_2 + C3_2 + C4_2 + C5_2
      TC7_2  <- C2_2 + C3_2 + C4_2 + C5_2 + C6_2
      TC8_2  <- C2_2 + C3_2 + C4_2 + C5_2 + C6_2 + C7_2
      TC9_2  <- C2_2 + C3_2 + C4_2 + C5_2 + C6_2 + C7_2 + C8_2
      TC10_2 <- C2_2 + C3_2 + C4_2 + C5_2 + C6_2 + C7_2 + C8_2 + C9_2
      
      
      if (IP==5) {
        
        Post_N[i] <- (C2_1*R02 + C3_1*R03 + C4_1*R04) + (p0_1 - TC5_1)*R05
        Post_S[i] <- (C2_2*R02 + C3_2*R03 + C4_2*R04) + (p0_2 - TC5_2)*R05
        
        Post_N_IP[i] <- (C2_1*2 + C3_1*3 + C4_1*4) + (p0_1 - TC5_1)*5
        Post_S_IP[i] <- (C2_2*2 + C3_2*3 + C4_2*4) + (p0_2 - TC5_2)*5
        
      } else if (IP==6){
        
        Post_N[i] <- (C2_1*R02 + C3_1*R03 + C4_1*R04 + C5_1*R05) + (p0_1 - TC6_1)*R06
        Post_S[i] <- (C2_2*R02 + C3_2*R03 + C4_2*R04 + C5_2*R05) + (p0_2 - TC6_2)*R06
        
        Post_N_IP[i] <- (C2_1*2 + C3_1*3 + C4_1*4 + C5_1*5) + (p0_1 - TC6_1)*6
        Post_S_IP[i] <- (C2_2*2 + C3_2*3 + C4_2*4 + C5_2*5) + (p0_2 - TC6_2)*6
        
      } else if (IP==7){
        
        Post_N[i] <- (C2_1*R02 + C3_1*R03 + C4_1*R04 + C5_1*R05 + C6_1*R06) + (p0_1 - TC7_1)*R07
        Post_S[i] <- (C2_2*R02 + C3_2*R03 + C4_2*R04 + C5_2*R05 + C6_2*R06) + (p0_2 - TC7_2)*R07
        
        Post_N_IP[i] <- (C2_1*2 + C3_1*3 + C4_1*4 + C5_1*5 + C6_1*6) + (p0_1 - TC7_1)*7
        Post_S_IP[i] <- (C2_2*2 + C3_2*3 + C4_2*4 + C5_2*5 + C6_2*6) + (p0_2 - TC7_2)*7
        
      } else if (IP==8){
        
        Post_N[i] <- (C2_1*R02 + C3_1*R03 + C4_1*R04 + C5_1*R05 + C6_1*R06 + C7_1*R07) + (p0_1 - TC8_1)*R08
        Post_S[i] <- (C2_2*R02 + C3_2*R03 + C4_2*R04 + C5_2*R05 + C6_2*R06 + C7_2*R07) + (p0_2 - TC8_2)*R08
        
        Post_N_IP[i] <- (C2_1*2 + C3_1*3 + C4_1*4 + C5_1*5 + C6_1*6 + C7_1*7) + (p0_1 - TC8_1)*8
        Post_S_IP[i] <- (C2_2*2 + C3_2*3 + C4_2*4 + C5_2*5 + C6_2*6 + C7_2*7) + (p0_2 - TC8_2)*8
        
      } else if (IP==9){
        
        Post_N[i] <- (C2_1*R02 + C3_1*R03 + C4_1*R04 + C5_1*R05 + C6_1*R06 + C7_1*R07 + C8_1*R08) + (p0_1 - TC9_1)*R09
        Post_S[i] <- (C2_2*R02 + C3_2*R03 + C4_2*R04 + C5_2*R05 + C6_2*R06 + C7_2*R07 + C8_2*R08) + (p0_2 - TC9_2)*R09
        
        Post_N_IP[i] <- (C2_1*2 + C3_1*3 + C4_1*4 + C5_1*5 + C6_1*6 + C7_1*7 + C8_1*8) + (p0_1 - TC9_1)*9
        Post_S_IP[i] <- (C2_2*2 + C3_2*3 + C4_2*4 + C5_2*5 + C6_2*6 + C7_2*7 + C8_2*8) + (p0_2 - TC9_2)*9
        
      } else {
        
        Post_N[i] <- (C2_1*R02 + C3_1*R03 + C4_1*R04 + C5_1*R05 + C6_1*R06 + C7_1*R07 + C8_1*R08 + C9_1*R09) + (p0_1 - TC10_1)*R010
        Post_S[i] <- (C2_2*R02 + C3_2*R03 + C4_2*R04 + C5_2*R05 + C6_2*R06 + C7_2*R07 + C8_2*R08 + C9_2*R09) + (p0_2 - TC10_2)*R010
        
        Post_N_IP[i] <- (C2_1*2 + C3_1*3 + C4_1*4 + C5_1*5 + C6_1*6 + C7_1*7 + C8_1*8 + C9_1*9) + (p0_1 - TC10_1)*10
        Post_S_IP[i] <- (C2_2*2 + C3_2*3 + C4_2*4 + C5_2*5 + C6_2*6 + C7_2*7 + C8_2*8 + C9_2*9) + (p0_2 - TC10_2)*10
        
      }
      
    }
    
    Post_DL <- data.frame(R1=Post_N,R2=Post_S,ID=seq(1,N,by=1))
    
    R0_N <- c()
    R0_S <- c()
    
    r_N <- c() 
    r_S <- c()
    
    for (m in 1:100) {
      
      post <- Post_DL[sample(nrow(Post_DL), size = N, replace = TRUE), ]
      row.names(post) <- NULL
      
      R0_N[m] <- mean(post$R1)
      R0_S[m] <- mean(post$R2)
      
      r_N[m] <- mean((1-exp(-post$R1))*100)
      r_S[m] <- mean((1-exp(-post$R2))*100)
      
    }
    
    ########### Mean
    Post_N <- data.frame(value=Post_N)
    Post_S <- data.frame(value=Post_S)
    
    Post_N_IP <- data.frame(value=Post_N_IP)
    Post_S_IP <- data.frame(value=Post_S_IP)
    
    Nasal  <- c(DL,IP,mean(Post_N$value),mean((1-exp(-Post_N$value))*100),mean(Post_N_IP$value))
    Saliva <- c(DL,IP,mean(Post_S$value),mean((1-exp(-Post_S$value))*100),mean(Post_S_IP$value))
    
    Post_Nasal_Heatmap  <- rbind(Post_Nasal_Heatmap,Nasal)
    Post_Saliva_Heatmap <- rbind(Post_Saliva_Heatmap,Saliva)
    
    ########### Min (2.5th percentile)
    Nasal_min  <- c(DL,IP,quantile(R0_N,0.025),quantile(r_N,0.025))
    Saliva_min <- c(DL,IP,quantile(R0_S,0.025),quantile(r_S,0.025))
    
    Post_Nasal_Heatmap_min  <- rbind(Post_Nasal_Heatmap_min,Nasal_min)
    Post_Saliva_Heatmap_min <- rbind(Post_Saliva_Heatmap_min,Saliva_min)
    
    ########### Max (97.5th percentile)
    Nasal_max  <- c(DL,IP,quantile(R0_N,0.975),quantile(r_N,0.975))
    Saliva_max <- c(DL,IP,quantile(R0_S,0.975),quantile(r_S,0.975))
    
    Post_Nasal_Heatmap_max  <- rbind(Post_Nasal_Heatmap_max,Nasal_max)
    Post_Saliva_Heatmap_max <- rbind(Post_Saliva_Heatmap_max,Saliva_max)
    
    ########### Effect
    Effect <- c(DL,IP,mean(r_N-r_S),quantile(r_N-r_S,0.025),quantile(r_N-r_S,0.975),t.test(r_N-r_S, alternative = "greater", mu = 0)$p.value)
    Post_Effect <- rbind(Post_Effect,Effect)
       
  }
  
}

colnames(Post_Nasal_Heatmap)  <- c("DL","IP","R0","r")
colnames(Post_Saliva_Heatmap) <- c("DL","IP","R0","r")

colnames(Post_Nasal_Heatmap_min)  <- c("DL","IP","R0","r")
colnames(Post_Saliva_Heatmap_min) <- c("DL","IP","R0","r")

colnames(Post_Nasal_Heatmap_max)  <- c("DL","IP","R0","r")
colnames(Post_Saliva_Heatmap_max) <- c("DL","IP","R0","r")

colnames(Post_Effect) <- c("DL","IP","rD","rDmin","rDmax","r_test")


write.csv(Post_Nasal_Heatmap,"Post_Nasal_Heatmap.csv", row.names = FALSE)
write.csv(Post_Saliva_Heatmap,"Post_Saliva_Heatmap.csv", row.names = FALSE)

write.csv(Post_Nasal_Heatmap_min,"Post_Nasal_Heatmap_min.csv", row.names = FALSE)
write.csv(Post_Saliva_Heatmap_min,"Post_Saliva_Heatmap_min.csv", row.names = FALSE)

write.csv(Post_Nasal_Heatmap_max,"Post_Nasal_Heatmap_max.csv", row.names = FALSE)
write.csv(Post_Saliva_Heatmap_max,"Post_Saliva_Heatmap_max.csv", row.names = FALSE)

write.csv(Post_Effect_Heatmap,"Post_Effect_Heatmap.csv", row.names = FALSE)

Post_Nasal_Heatmap <- read.csv("Post_Nasal_Heatmap.csv")
Post_Saliva_Heatmap <- read.csv("Post_Saliva_Heatmap.csv")


install.packages("deSolve")
install.packages("dplyr")

library(deSolve)
library(dplyr)

set.seed(213)

setwd("~/Desktop/")


##################################### Setting
Tmin <- 0
Tmax <- 60
step_size <- 1
mtime <- seq(Tmin,Tmax,step_size)
N <- 10^4 ## # of samples

h <- 0.5471
Km <- 2.72*10^8

R0 <- 3.0


##################################### Viral dynamics model
Covfun <- function(pars){
  
  b <- as.numeric(pars[1])
  r <- as.numeric(pars[2])
  d <- as.numeric(pars[3])
  
  derivs <- function(time,y,pars){
    with(as.list(c(pars,y)),{
      
      dTa <- -b*Ta*V
      dV  <- r*Ta*V-d*V
      
      return(list(c(dTa,dV)))
    })
  }
  y<-c(Ta=1,V=0.01)
  
  times<-c(seq(Tmin,Tmax,step_size))
  out<-lsoda(y=y,parms=pars,times=times,func=derivs,rtol=0.00004,atol=0)
  out2<-cbind(time=out[,1],V=(log10(out[,3])))
  as.data.frame(out2)
}


##################################### Sampling
pop <- read.csv("populationParameters_Both.txt", row.names = 1)

fitt<-matrix(NA,nrow=N,ncol=7)
i <- 1
while (TRUE) {
  
  popb1 <- rlnorm(1, log(pop["b1_pop", "value"]), pop["omega_b1", "value"])
  popr1 <- rlnorm(1, log(pop["r1_pop", "value"]), pop["omega_r1", "value"]) 
  popd1 <- rlnorm(1, log(pop["d1_pop", "value"]), pop["omega_d1", "value"])
  
  popb2 <- rlnorm(1, log(pop["b2_pop", "value"]), pop["omega_b2", "value"])
  popr2 <- rlnorm(1, log(pop["r2_pop", "value"]), pop["omega_r2", "value"]) 
  popd2 <- rlnorm(1, log(pop["d2_pop", "value"]), pop["omega_d2", "value"])
  
  poptau <- round(rlnorm(1, log(pop["tau_pop", "value"]), pop["omega_tau", "value"]), digits = 0)
  
  pars1 <- c(popb1,popr1,popd1)
  pars2 <- c(popb2,popr2,popd2)
  
  out1 <- Covfun(pars1)
  out2 <- Covfun(pars2)
  
  FV1 <- 10^(out1$V[which(out1$time==Tmax)])
  FV2 <- 10^(out2$V[which(out2$time==Tmax)])
  
  FP <- (FV1^h)/(FV1^h + Km^h) + (FV2^h)/(FV2^h + Km^h)

  if (FP <= 10^-3) {
    fitt[i,] <- c(popb1,popr1,popd1,popb2,popr2,popd2,poptau)
    i <- i+1
    if (i > N)
      break
  }
}
fitt <- data.frame(fitt)
colnames(fitt) <- c("b1","r1","d1","b2","r2","d2","tau")


##################################### Running model
All <- data.frame()

for (i in 1:N) {
  
  pars1 <- c(b=fitt$b1[i],r=fitt$r1[i],d=fitt$d1[i])
  pars2 <- c(b=fitt$b2[i],r=fitt$r2[i],d=fitt$d2[i])
  
  out1  <- Covfun(pars1)
  out2  <- Covfun(pars2)
  
  ppp <- matrix(NA,nrow=length(mtime),ncol=2)
  
  for (j in 1:length(mtime)) {
    
    ii<-j
    a<-mtime[ii]
    dd1<-out1[out1$time==a,]
    dd2<-out2[out2$time==a,]
    ppp[ii,1]<-dd1$V
    ppp[ii,2]<-dd2$V
    
  }
  
  pp <- data.frame(ID=i, time=mtime, V1=ppp[,1], V2=ppp[,2], IP=rep(fitt$tau[i], times=length(mtime)))
  All <- rbind(All,pp)
  
}

write.csv(All,"VL.csv", row.names = FALSE)




install.packages("dplyr")
install.packages("bayestestR")

library(dplyr)
library(bayestestR) 


setwd("~/Desktop/")


###########################################################################################
######################################## 1.Setting ########################################
###########################################################################################
Tmin <- 0
Tmax <- 60
step_size <- 1
mtime <- seq(Tmin,Tmax,step_size)
N <- 10^4 ## # of samples

DLmin <- 2
DLmax <- 7
Step_size <- 0.1

SI <- 6 ## Serial interval

pop <- read.csv("populationParameters_Both.txt", row.names = 1)
All <- read.csv("VL.csv")




##########################################################################################################################
##################################### 2.Computing scaling constant of infectiousness #####################################
##########################################################################################################################
h <- 0.5471
Km <- 2.72*10^8
R <- 3.0
All$IF <- ((10^(All$V1*h)/(10^(All$V1*h)+Km^h))) + ((10^(All$V2*h)/(10^(All$V2*h)+Km^h)))

Rall <- c()
for (i in 1:N) {
  
  all <- subset(All,All$ID==i)
  Rall[i] <- auc(all$time,all$IF)
  
}
C <- R/mean(Rall)




####################################################################################################################
##################################### 3.Screening in the pre-symptomatic phase #####################################
####################################################################################################################

alpha <- seq(0,1,by=0.01)

Pre_1 <- matrix(NA,nrow=length(alpha),ncol=2)
Pre_2 <- matrix(NA,nrow=length(alpha),ncol=2)

for (k in 1:length(alpha)) {
  
  alpha_1 <- alpha[k]
  alpha_2 <- alpha[k]
  
  # totalIF <- c()
  totalIF_Nasal <- c()
  totalIF_Saliva <- c()
  
  DL <- 6
  
  All$P1 <- pnorm(DL,mean=All$V1, sd=pop["a1", "value"], lower.tail=FALSE) * alpha_1
  All$P2 <- pnorm(DL,mean=All$V2, sd=pop["a2", "value"], lower.tail=FALSE) * alpha_2
  
  for ( i in 1:N ) {
    
    all <- subset(All,All$ID==i)
    all <- subset(all,all$time<=all$IP[1])
    R0  <- C*auc(all$time,all$IF)
    # SI <- all$SI[1]
    
    if (all$IP[1]-SI <= 0 & SI > 0) {
      
      R1 <- 0
      R2 <- 0
      
      for ( j in 1:(all$IP[1]-1) ) {
        
        all2 <- subset(all,all$time<=j)
        
        p1 <- all$P1[all$time==j]
        p2 <- all$P2[all$time==j]
        
        R11 <- C*auc(all2$time,all2$IF)
        R22 <- C*auc(all2$time,all2$IF)
        
        R1 <- R1 + (p1*R11+(1-p1)*R0)
        R2 <- R2 + (p2*R22+(1-p2)*R0)
        
      }
      
      # totalIF[i] <- R0
      totalIF_Nasal[i]  <- 1/(SI)*((SI-all$IP[1]+1)*R0 + R1)
      totalIF_Saliva[i] <- 1/(SI)*((SI-all$IP[1]+1)*R0 + R2)
      
    } else if (all$IP[1]-SI > 0 & SI > 0)  {
      
      R1 <- 0
      R2 <- 0
      
      for ( j in (all$IP[1]-SI):(all$IP[1]-1) ) {
        
        all2 <- subset(all,all$time<=j)
        
        p1 <- all$P1[all$time==j]
        p2 <- all$P2[all$time==j]
        
        R11 <- C*auc(all2$time,all2$IF)
        R22 <- C*auc(all2$time,all2$IF)
        
        R1 <- R1 + (p1*R11+(1-p1)*R0)
        R2 <- R2 + (p2*R22+(1-p2)*R0)
        
      }
      
      # totalIF[i] <- R0
      totalIF_Nasal[i]  <- 1/(SI)*(R1)
      totalIF_Saliva[i] <- 1/(SI)*(R2)
      
    } else {
      
      # totalIF[i] <- R0
      totalIF_Nasal[i]  <- R0
      totalIF_Saliva[i] <- R0
      
    }
    
  }
  
  # TotalIF <- data.frame(value=totalIF,group=rep(0,times=N))
  TotalIF_Nasal <- data.frame(value=totalIF_Nasal,group=rep(1,times=N))
  TotalIF_Saliva <- data.frame(value=totalIF_Saliva,group=rep(2,times=N))
  
  pre <- data.frame(R1=TotalIF_Nasal$value,R2=TotalIF_Saliva$value,ID=seq(1,N,by=1))
  risk <- data.frame(value=c((1-exp(-pre$R1))*100,(1-exp(-pre$R2))*100),group=rep(c("1","2"),each=N))
  
  Pre_1[k,1] <- alpha_1
  Pre_2[k,1] <- alpha_2
  
  Pre_1[k,2] <- mean(risk$value[risk$group=="1"])
  Pre_2[k,2] <- mean(risk$value[risk$group=="2"])

}

Pre_1 <- data.frame(alpha=Pre_1[,1],value=Pre_1[,2])
Pre_2 <- data.frame(alpha=Pre_2[,1],value=Pre_2[,2])

write.csv(Pre_1,"Pre_nasal_alpha.csv")
write.csv(Pre_2,"Pre_saliva_alpha.csv")


############################################################################################################################
##################################### 4.Ending isolation in the post-symptomatic phase #####################################
############################################################################################################################

alpha <- seq(0,1,by=0.01)

Post_1 <- matrix(NA,nrow=length(alpha),ncol=2)
Post_2 <- matrix(NA,nrow=length(alpha),ncol=2)

for (k in 1:length(alpha)) {
  
  alpha_1 <- alpha[k]
  alpha_2 <- alpha[k]
  
  # totalIF <- c()
  totalIF_Nasal <- c()
  totalIF_Saliva <- c()
  # totalIF_Full <- c()
  
  DL <- 6
  
  All$P1 <- pnorm(DL,mean=All$V1, sd=pop["a1", "value"], lower.tail=FALSE) * alpha_1
  All$P2 <- pnorm(DL,mean=All$V2, sd=pop["a2", "value"], lower.tail=FALSE) * alpha_2
  
  for ( i in 1:N ) {
    
    all <- subset(All,All$ID==i)
    all <- subset(all,all$time>=all$IP[1])
    R0  <- C*auc(all$time,all$IF)
    
    ####### Infectiousness for each time (time >= 2)
    all2 <- subset(all,all$time>=all$IP[1]+2)
    all3 <- subset(all,all$time>=all$IP[1]+3)
    all4 <- subset(all,all$time>=all$IP[1]+4)
    all5 <- subset(all,all$time>=all$IP[1]+5)
    # all6 <- subset(all,all$time>=all$IP[1]+6)
    # all7 <- subset(all,all$time>=all$IP[1]+7)
    # all8 <- subset(all,all$time>=all$IP[1]+8)
    # all9 <- subset(all,all$time>=all$IP[1]+9)
    # all10 <- subset(all,all$time>=all$IP[1]+10)
    
    R02 <- C*auc(all2$time,all2$IF)
    R03 <- C*auc(all3$time,all3$IF)
    R04 <- C*auc(all4$time,all4$IF)
    R05 <- C*auc(all5$time,all5$IF)
    # R06 <- C*auc(all6$time,all6$IF)
    # R07 <- C*auc(all7$time,all7$IF)
    # R08 <- C*auc(all8$time,all8$IF)
    # R09 <- C*auc(all9$time,all9$IF)
    # R010 <- C*auc(all10$time,all10$IF)
    
    
    ####### Probability of detection for each time since symptom onset
    ## Nasal
    p0_1 <- 1
    p1_1 <- all$P1[all$time==all$IP[1]+1]
    p2_1 <- all$P1[all$time==all$IP[1]+2]
    p3_1 <- all$P1[all$time==all$IP[1]+3]
    p4_1 <- all$P1[all$time==all$IP[1]+4]
    # p5_1 <- all$P1[all$time==all$IP[1]+5]
    # p6_1 <- all$P1[all$time==all$IP[1]+6]
    # p7_1 <- all$P1[all$time==all$IP[1]+7]
    # p8_1 <- all$P1[all$time==all$IP[1]+8]
    # p9_1 <- all$P1[all$time==all$IP[1]+9]
    # p10_1 <- all$P1[all$time==all$IP[1]+10]
    
    ## Saliva
    p0_2 <- 1
    p1_2 <- all$P2[all$time==all$IP[1]+1]
    p2_2 <- all$P2[all$time==all$IP[1]+2]
    p3_2 <- all$P2[all$time==all$IP[1]+3]
    p4_2 <- all$P2[all$time==all$IP[1]+4]
    # p5_2 <- all$P2[all$time==all$IP[1]+5]
    # p6_2 <- all$P2[all$time==all$IP[1]+6]
    # p7_2 <- all$P2[all$time==all$IP[1]+7]
    # p8_2 <- all$P2[all$time==all$IP[1]+8]
    # p9_2 <- all$P2[all$time==all$IP[1]+9]
    # p10_2 <- all$P2[all$time==all$IP[1]+10]
    
    
    ####### Coefficients of probability for each infectiousness (time >= 2)
    ## Nasal
    C2_1 <- p0_1*(1-p1_1)*(1-p2_1) 
    C3_1 <- p0_1*p1_1*(1-p2_1)*(1-p3_1)
    C4_1 <- p0_1*(1)*p2_1*(1-p3_1)*(1-p4_1)
    
    
    ## Saliva
    C2_2 <- p0_2*(1-p1_2)*(1-p2_2) 
    C3_2 <- p0_2*p1_2*(1-p2_2)*(1-p3_2)
    C4_2 <- p0_2*(1)*p2_2*(1-p3_2)*(1-p4_2)
    
    # totalIF[i] <- R0
    totalIF_Nasal[i]  <- (C2_1*R02 + C3_1*R03 + C4_1*R04) + (p0_1 - (C2_1+C3_1+C4_1))*R05
    totalIF_Saliva[i] <- (C2_2*R02 + C3_2*R03 + C4_2*R04) + (p0_2 - (C2_2+C3_2+C4_2))*R05
    # totalIF_Full[i] <- R05
    
  }
  
  # TotalIF <- data.frame(value=totalIF,group=rep(0,times=N))
  TotalIF_Nasal <- data.frame(value=totalIF_Nasal,group=rep(1,times=N))
  TotalIF_Saliva <- data.frame(value=totalIF_Saliva,group=rep(2,times=N))
  # TotalIF_Full <- data.frame(value=totalIF_Full,group=rep(0,times=N))
  
  post <- data.frame(R1=TotalIF_Nasal$value,R2=TotalIF_Saliva$value,ID=seq(1,N,by=1))
  risk <- data.frame(value=c((1-exp(-post$R1))*100,(1-exp(-post$R2))*100),group=rep(c("1","2"),each=N))
  
  Post_1[k,1] <- alpha_1
  Post_2[k,1] <- alpha_2
  
  Post_1[k,2] <- mean(risk$value[risk$group=="1"])
  Post_2[k,2] <- mean(risk$value[risk$group=="2"])
  
}

Post_1 <- data.frame(alpha=Post_1[,1],value=Post_1[,2])
Post_2 <- data.frame(alpha=Post_2[,1],value=Post_2[,2])

write.csv(Post_1,"Post_nasal_alpha.csv")
write.csv(Post_2,"Post_saliva_alpha.csv")





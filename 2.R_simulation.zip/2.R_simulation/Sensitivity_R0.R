install.packages("dplyr")
install.packages("bayestestR")

library(dplyr)
library(bayestestR) 

set.seed(66)

setwd("~/Desktop/")


#########################################################################################
######################################## Setting ########################################
#########################################################################################
Tmin <- 0
Tmax <- 60
step_size <- 1
mtime <- seq(Tmin,Tmax,step_size)
N <- 10^4 ## # of samples

R0min <- 1.5
R0max <- 6.0
Step_size <- 0.1

DL <- 6 ## Limit of detection
SI <- 6 ## Serial interval

pop <- read.csv("populationParameters_Both.txt", row.names = 1)
All <- read.csv("VL.csv")




########################################################################################################################
##################################### Computing scaling constant of infectiousness #####################################
########################################################################################################################
h <- 0.5471
Km <- 2.72*10^8
R <- 3.0
All$IF <- ((10^(All$V1*h)/(10^(All$V1*h)+Km^h))) + ((10^(All$V2*h)/(10^(All$V2*h)+Km^h)))

L <- length(seq(R0min,R0max,by=Step_size))
C <- c()

for (l in 1:L) {
  
  R0 <- R0min + (l-1)*Step_size
  
  Rall <- c()
  for (j in 1:N) {
    
    all <- subset(All,All$ID==j)
    Rall[j] <- auc(all$time,all$IF)

  }
  
  C[l] <- R0/mean(Rall) ## Scaling constant
  
}

R0_constant <- data.frame(R0=seq(R0min,R0max,Step_size),C=C)
# write.csv(R0_constant,"R0_constant.csv", row.names = FALSE)
R0_constant <- read.csv("R0_constant.csv")
C <- as.vector(R0_constant$C)


############################################################################################
######################################## R0_Heatmap ########################################
############################################################################################
All$Time <- All$time - All$IP

Min <- max(All$Time[which(All$time==Tmin)])
Max <- min(All$Time[which(All$time==Tmax)])
M <- length(seq(Min,Max,by=step_size))

IF <- matrix(NA,nrow=M,ncol=L)

for (l in 1:L) {
  
  all <- All
  c <- C[l]
  all$IF <- c*all$IF 
  
  for (m in 1:M) {
    
    all_m <- subset(all,all$Time==(Min + (m-1)*step_size))
    
    IF[m,l] <- mean(all_m$IF)
    
  }
  
}

IF <- as.vector(IF)
IF <- data.frame(time=rep(seq(Min,Max,by=step_size),times=L),
                 R0=rep(seq(R0min,R0max,by=Step_size),each=M),
                 value=IF)





###########################################################################################
##################################### Pre-symptomatic #####################################
###########################################################################################
Pre_Nasal_R0  <- matrix(NA,nrow=L,ncol=10)
Pre_Saliva_R0 <- matrix(NA,nrow=L,ncol=10)
Pre_Effect_R0 <- matrix(NA,nrow=L,ncol=13)

for ( k in 1:L ) {
  
  BR0 <- R0min + (k-1)*Step_size
  c <- C[k]
  
  ##################################### Probability of positive results
  All$P1 <- pnorm(DL,mean=All$V1, sd=pop["a1", "value"], lower.tail=FALSE)
  All$P2 <- pnorm(DL,mean=All$V2, sd=pop["a2", "value"], lower.tail=FALSE)
  
  
  ##################################### Self-screening with tests
  Pre <- c()
  Pre_N <- c()
  Pre_S <- c()
  
  for ( i in 1:N ) {
    
    all <- subset(All,All$ID==i)
    all <- subset(all,all$time<=all$IP[1])
    R0  <- c*auc(all$time,all$IF)
    Pre[i] <- R0
    
    if (all$IP[1]-SI <= 0 & SI > 0) {
      
      R1 <- 0
      R2 <- 0
      
      for ( j in 1:(all$IP[1]-1) ) {
        
        all2 <- subset(all,all$time<=j)
        
        p1 <- all$P1[all$time==j]
        p2 <- all$P2[all$time==j]
        
        R11 <- c*auc(all2$time,all2$IF)
        R22 <- c*auc(all2$time,all2$IF)
        
        R1 <- R1 + (p1*(R11)+(1-p1)*(R0))
        R2 <- R2 + (p2*(R22)+(1-p2)*(R0))
        
      }
      
      Pre_N[i] <- 1/SI*((SI-all$IP[1]+1)*(R0) + R1)
      Pre_S[i] <- 1/SI*((SI-all$IP[1]+1)*(R0) + R2)
      
    } else if (all$IP[1]-SI > 0 & SI > 0) {
      
      R1 <- 0
      R2 <- 0
      
      for ( j in (all$IP[1]-SI):(all$IP[1]-1) ) {
        
        all2 <- subset(all,all$time<=j)
        
        p1 <- all$P1[all$time==j]
        p2 <- all$P2[all$time==j]
        
        R11 <- c*auc(all2$time,all2$IF)
        R22 <- c*auc(all2$time,all2$IF)
        
        R1 <- R1 + (p1*(R11)+(1-p1)*(R0))
        R2 <- R2 + (p2*(R22)+(1-p2)*(R0))
        
      }
      
      Pre_N[i] <- 1/SI*(R1)
      Pre_S[i] <- 1/SI*(R2)
      
    } else {
      
      Pre_N[i] <- R0
      Pre_S[i] <- R0
      
    }
    
  }
  
  Pre_Nasal_R0[k,1]  <- BR0
  Pre_Saliva_R0[k,1] <- BR0
  Pre_Effect_R0[k,1] <- BR0
  
  ########### Arranging
  Pre_R0 <- data.frame(R0=Pre,R1=Pre_N,R2=Pre_S,ID=seq(1,N,by=1))
  
  R0_N <- c()
  R0_S <- c()
  
  R_N <- c()
  R_S <- c()
  
  r_N <- c() 
  r_S <- c()
  
  for (l in 1:100) {
    
    # id <- sample(Pre_R0$ID,100)
    # pre <- subset(Pre_R0,Pre_R0$ID %in% id)
    
    pre <- Pre_R0[sample(nrow(Pre_R0), size = N, replace = TRUE), ]
    row.names(pre) <- NULL
    
    R0_N[l] <- mean(pre$R1)
    R0_S[l] <- mean(pre$R2)
    
    R_N[l] <- mean((pre$R0-pre$R1)/pre$R0*100)
    R_S[l] <- mean((pre$R0-pre$R2)/pre$R0*100)
    
    r_N[l] <- mean((1-exp(-pre$R1))*100)
    r_S[l] <- mean((1-exp(-pre$R2))*100)
    
  }
  
  Pre_Nasal_R0[k,2]  <- mean(Pre_N)
  Pre_Nasal_R0[k,3]  <- quantile(R0_N,0.025)
  Pre_Nasal_R0[k,4]  <- quantile(R0_N,0.975)
  Pre_Nasal_R0[k,5]  <- mean((Pre-Pre_N)/Pre*100)
  Pre_Nasal_R0[k,6]  <- quantile(R_N,0.025)
  Pre_Nasal_R0[k,7]  <- quantile(R_N,0.975)
  Pre_Nasal_R0[k,8]  <- mean((1-exp(-Pre_N))*100)
  Pre_Nasal_R0[k,9]  <- quantile(r_N,0.025)
  Pre_Nasal_R0[k,10] <- quantile(r_N,0.975)
  
  Pre_Saliva_R0[k,2]  <- mean(Pre_S)
  Pre_Saliva_R0[k,3]  <- quantile(R0_S,0.025)
  Pre_Saliva_R0[k,4]  <- quantile(R0_S,0.975)
  Pre_Saliva_R0[k,5]  <- mean((Pre-Pre_S)/Pre*100)
  Pre_Saliva_R0[k,6]  <- quantile(R_S,0.025)
  Pre_Saliva_R0[k,7]  <- quantile(R_S,0.975)
  Pre_Saliva_R0[k,8]  <- mean((1-exp(-Pre_S))*100)
  Pre_Saliva_R0[k,9]  <- quantile(r_S,0.025)
  Pre_Saliva_R0[k,10] <- quantile(r_S,0.975)
  
  Pre_Effect_R0[k,2]  <- mean(R0_N - R0_S)
  Pre_Effect_R0[k,3]  <- quantile(R0_N - R0_S,0.025)
  Pre_Effect_R0[k,4]  <- quantile(R0_N - R0_S,0.975)
  Pre_Effect_R0[k,5]  <- mean(R_N - R_S)
  Pre_Effect_R0[k,6]  <- quantile(R_N - R_S,0.025)
  Pre_Effect_R0[k,7]  <- quantile(R_N - R_S,0.975)
  Pre_Effect_R0[k,8]  <- mean(r_N - r_S)
  Pre_Effect_R0[k,9]  <- quantile(r_N - r_S,0.025)
  Pre_Effect_R0[k,10] <- quantile(r_N - r_S,0.975)
  Pre_Effect_R0[k,11] <- t.test(R0_N - R0_S, alternative = "greater", mu = 0)$p.value
  Pre_Effect_R0[k,12] <- t.test(R_N - R_S, alternative = "less", mu = 0)$p.value
  Pre_Effect_R0[k,13] <- t.test(r_N - r_S, alternative = "greater", mu = 0)$p.value
  
}

Pre_Nasal_R0 <- data.frame(Pre_Nasal_R0)
Pre_Saliva_R0 <- data.frame(Pre_Saliva_R0)
Pre_Effect_R0 <- data.frame(Pre_Effect_R0)

colnames(Pre_Nasal_R0)  <- c("R0","R","Rmin","Rmax","RT","RTmin","RTmax","r","rmin","rmax")
colnames(Pre_Saliva_R0) <- c("R0","R","Rmin","Rmax","RT","RTmin","RTmax","r","rmin","rmax")
colnames(Pre_Effect_R0) <- c("R0","R0D","R0Dmin","R0Dmax","RD","RDmin","RDmax","rD","rDmin","rDmax","R0_test","R_test","r_test")

write.csv(Pre_Nasal_R0,"Pre_Nasal_R0.csv", row.names = FALSE)
write.csv(Pre_Saliva_R0,"Pre_Saliva_R0.csv", row.names = FALSE)
write.csv(Pre_Effect_R0,"Pre_Effect_R0.csv", row.names = FALSE)

Pre_Nasal_R0 <- read.csv("Pre_Nasal_R0.csv")
Pre_Saliva_R0 <- read.csv("Pre_Saliva_R0.csv")
Pre_Effect_R0 <- read.csv("Pre_Effect_R0.csv")







############################################################################################
##################################### Post-symptomatic #####################################
############################################################################################
Post_Nasal_R0  <- matrix(NA,nrow=L,ncol=13)
Post_Saliva_R0 <- matrix(NA,nrow=L,ncol=13)
Post_Effect_R0 <- matrix(NA,nrow=L,ncol=17)

for ( k in 1:L ) {
  
  BR0 <- R0min + (k-1)*Step_size
  c <- C[k]
  
  ##################################### Probability of positive results
  All$P1 <- pnorm(DL,mean=All$V1, sd=pop["a1", "value"], lower.tail=FALSE)
  All$P2 <- pnorm(DL,mean=All$V2, sd=pop["a2", "value"], lower.tail=FALSE)
  
  
  ##################################### Ending isolation by test
  Post <- c()
  Post_N <- c()
  Post_S <- c()
  
  Post_N_IP <- c()
  Post_S_IP <- c()
  
  for ( i in 1:N ) {
    
    all <- subset(All,All$ID==i)
    all <- subset(all,all$time>=all$IP[1])
    R0 <- c*auc(all$time,all$IF)
    Post[i] <- R0
    
    ####### Infectiousness for each time (time >= 2)
    all2 <- subset(all,all$time>=all$IP[1]+2)
    all3 <- subset(all,all$time>=all$IP[1]+3)
    all4 <- subset(all,all$time>=all$IP[1]+4)
    all5 <- subset(all,all$time>=all$IP[1]+5)
    # all6 <- subset(all,all$time>=all$IP[1]+6)
    # all7 <- subset(all,all$time>=all$IP[1]+7)
    # all8 <- subset(all,all$time>=all$IP[1]+8)
    # all9 <- subset(all,all$time>=all$IP[1]+9)
    # all10 <- subset(all,all$time>=all$IP[1]+10)
    
    R02 <- c*auc(all2$time,all2$IF)
    R03 <- c*auc(all3$time,all3$IF)
    R04 <- c*auc(all4$time,all4$IF)
    R05 <- c*auc(all5$time,all5$IF)
    # R06 <- c*auc(all6$time,all6$IF)
    # R07 <- c*auc(all7$time,all7$IF)
    # R08 <- c*auc(all8$time,all8$IF)
    # R09 <- c*auc(all9$time,all9$IF)
    # R010 <- c*auc(all10$time,all10$IF)
    
    
    ####### Probability of detection for each time since symptom onset
    ## Nasal
    p0_1 <- 1
    p1_1 <- all$P1[all$time==all$IP[1]+1]
    p2_1 <- all$P1[all$time==all$IP[1]+2]
    p3_1 <- all$P1[all$time==all$IP[1]+3]
    p4_1 <- all$P1[all$time==all$IP[1]+4]
    # p5_1 <- all$P1[all$time==all$IP[1]+5]
    # p6_1 <- all$P1[all$time==all$IP[1]+6]
    # p7_1 <- all$P1[all$time==all$IP[1]+7]
    # p8_1 <- all$P1[all$time==all$IP[1]+8]
    # p9_1 <- all$P1[all$time==all$IP[1]+9]
    # p10_1 <- all$P1[all$time==all$IP[1]+10]
    
    ## Saliva
    p0_2 <- 1
    p1_2 <- all$P2[all$time==all$IP[1]+1]
    p2_2 <- all$P2[all$time==all$IP[1]+2]
    p3_2 <- all$P2[all$time==all$IP[1]+3]
    p4_2 <- all$P2[all$time==all$IP[1]+4]
    # p5_2 <- all$P2[all$time==all$IP[1]+5]
    # p6_2 <- all$P2[all$time==all$IP[1]+6]
    # p7_2 <- all$P2[all$time==all$IP[1]+7]
    # p8_2 <- all$P2[all$time==all$IP[1]+8]
    # p9_2 <- all$P2[all$time==all$IP[1]+9]
    # p10_2 <- all$P2[all$time==all$IP[1]+10]
    
    
    ####### Coefficients of probability for each infectiousness (time >= 2)
    ## Nasal
    C2_1 <- p0_1*(1-p1_1)*(1-p2_1) 
    C3_1 <- p0_1*p1_1*(1-p2_1)*(1-p3_1)
    C4_1 <- p0_1*(1)*p2_1*(1-p3_1)*(1-p4_1)
    # C5_1 <- (p0_1 - 
    #          p0_1*(1-p1_1)*(1-p2_1)) * p3_1*(1-p4_1)*(1-p5_1)
    # C6_1 <- (p0_1 - 
    #          p0_1*(1-p1_1)*(1-p2_1) - 
    #          p0_1*p1_1*(1-p2_1)*(1-p3_1)) * p4_1*(1-p5_1)*(1-p6_1)
    # C7_1 <- (p0_1 - 
    #          p0_1*(1-p1_1)*(1-p2_1) - 
    #          p0_1*p1_1*(1-p2_1)*(1-p3_1) -
    #          p0_1*p1_1*p2_1*(1-p3_1)*(1-p4_1)) * p5_1*(1-p6_1)*(1-p7_1)
    # C8_1 <- (p0_1 - 
    #          p0_1*(1-p1_1)*(1-p2_1) - 
    #          p0_1*p1_1*(1-p2_1)*(1-p3_1) -
    #          p0_1*p1_1*p2_1*(1-p3_1)*(1-p4_1) -
    #          p0_1*p1_1*p2_1*p3_1*(1-p4_1)*(1-p5_1)) * p6_1*(1-p7_1)*(1-p8_1)
    # C9_1 <- (p0_1 - 
    #          p0_1*(1-p1_1)*(1-p2_1) - 
    #          p0_1*p1_1*(1-p2_1)*(1-p3_1) -
    #          p0_1*p1_1*p2_1*(1-p3_1)*(1-p4_1) -
    #          p0_1*p1_1*p2_1*p3_1*(1-p4_1)*(1-p5_1) -
    #          p0_1*p1_1*p2_1*p3_1*p4_1*(1-p5_1)*(1-p6_1)) * p7_1*(1-p8_1)*(1-p9_1)
    # C10_1 <-(p0_1 - 
    #          p0_1*(1-p1_1)*(1-p2_1) - 
    #          p0_1*p1_1*(1-p2_1)*(1-p3_1) -
    #          p0_1*p1_1*p2_1*(1-p3_1)*(1-p4_1) -
    #          p0_1*p1_1*p2_1*p3_1*(1-p4_1)*(1-p5_1) -
    #          p0_1*p1_1*p2_1*p3_1*p4_1*(1-p5_1)*(1-p6_1) -
    #          p0_1*p1_1*p2_1*p3_1*p4_1*p5_1*(1-p6_1)*(1-p7_1)) * p8_1*(1-p9_1)*(1-p10_1)
    
    ## Saliva
    C2_2 <- p0_2*(1-p1_2)*(1-p2_2) 
    C3_2 <- p0_2*p1_2*(1-p2_2)*(1-p3_2)
    C4_2 <- p0_2*(1)*p2_2*(1-p3_2)*(1-p4_2)
    # C5_2 <- (p0_2 -
    #          p0_2*(1-p1_2)*(1-p2_2)) * p3_2*(1-p4_2)*(1-p5_2)
    # C6_2 <- (p0_2 -
    #          p0_2*(1-p1_2)*(1-p2_2) -
    #          p0_2*p1_2*(1-p2_2)*(1-p3_2)) * p4_2*(1-p5_2)*(1-p6_2)
    # C7_2 <- (p0_2 -
    #          p0_2*(1-p1_2)*(1-p2_2) -
    #          p0_2*p1_2*(1-p2_2)*(1-p3_2) -
    #          p0_2*p1_2*p2_2*(1-p3_2)*(1-p4_2)) * p5_2*(1-p6_2)*(1-p7_2)
    # C8_2 <- (p0_2 -
    #          p0_2*(1-p1_2)*(1-p2_2) -
    #          p0_2*p1_2*(1-p2_2)*(1-p3_2) -
    #          p0_2*p1_2*p2_2*(1-p3_2)*(1-p4_2) -
    #          p0_2*p1_2*p2_2*p3_2*(1-p4_2)*(1-p5_2)) * p6_2*(1-p7_2)*(1-p8_2)
    # C9_2 <- (p0_2 -
    #          p0_2*(1-p1_2)*(1-p2_2) -
    #          p0_2*p1_2*(1-p2_2)*(1-p3_2) -
    #          p0_2*p1_2*p2_2*(1-p3_2)*(1-p4_2) -
    #          p0_2*p1_2*p2_2*p3_2*(1-p4_2)*(1-p5_2) -
    #          p0_2*p1_2*p2_2*p3_2*p4_2*(1-p5_2)*(1-p6_2)) * p7_2*(1-p8_2)*(1-p9_2)
    # C10_2 <-(p0_2 -
    #          p0_2*(1-p1_2)*(1-p2_2) -
    #          p0_2*p1_2*(1-p2_2)*(1-p3_2) -
    #          p0_2*p1_2*p2_2*(1-p3_2)*(1-p4_2) -
    #          p0_2*p1_2*p2_2*p3_2*(1-p4_2)*(1-p5_2) -
    #          p0_2*p1_2*p2_2*p3_2*p4_2*(1-p5_2)*(1-p6_2) -
    #          p0_2*p1_2*p2_2*p3_2*p4_2*p5_2*(1-p6_2)*(1-p7_2)) * p8_2*(1-p9_2)*(1-p10_2)
    
    Post_N[i] <- (C2_1*R02 + C3_1*R03 + C4_1*R04) + (p0_1 - (C2_1+C3_1+C4_1))*R05
    Post_S[i] <- (C2_2*R02 + C3_2*R03 + C4_2*R04) + (p0_2 - (C2_2+C3_2+C4_2))*R05
    
    Post_N_IP[i] <- 2*(C2_1) + 3*(C3_1) + 4*(C4_1) + 5*(p0_1 - (C2_1+C3_1+C4_1))
    Post_S_IP[i] <- 2*(C2_2) + 3*(C3_2) + 4*(C4_2) + 5*(p0_2 - (C2_2+C3_2+C4_2))
    
  }
  
  Post_Nasal_R0[k,1]  <- BR0
  Post_Saliva_R0[k,1] <- BR0
  Post_Effect_R0[k,1] <- BR0
  
  ########### Arranging
  Post_R0 <- data.frame(R0=Post,R1=Post_N,R2=Post_S,IP1=Post_N_IP,IP2=Post_S_IP,ID=seq(1,N,by=1))
  
  R0_N <- c()
  R0_S <- c()
  
  R_N <- c()
  R_S <- c()
  
  r_N <- c() 
  r_S <- c()
  
  IP_N <- c()
  IP_S <- c()
  
  for (l in 1:100) {
    
    # id <- sample(Post_R0$ID,100)
    # post <- subset(Post_R0,Post_R0$ID %in% id)
    
    post <- Post_R0[sample(nrow(Post_R0), size = N, replace = TRUE), ]
    row.names(post) <- NULL
    
    R0_N[l] <- mean(post$R1)
    R0_S[l] <- mean(post$R2)
    
    R_N[l] <- mean((post$R0-post$R1)/post$R0*100)
    R_S[l] <- mean((post$R0-post$R2)/post$R0*100)
    
    r_N[l] <- mean((1-exp(-post$R1))*100)
    r_S[l] <- mean((1-exp(-post$R2))*100)
    
    IP_N[l] <- mean(post$IP1)
    IP_S[l] <- mean(post$IP2)
    
  }
  
  Post_Nasal_R0[k,2]  <- mean(Post_N)
  Post_Nasal_R0[k,3]  <- quantile(R0_N,0.025)
  Post_Nasal_R0[k,4]  <- quantile(R0_N,0.975)
  Post_Nasal_R0[k,5]  <- mean((Post-Post_N)/Post*100)
  Post_Nasal_R0[k,6]  <- quantile(R_N,0.025)
  Post_Nasal_R0[k,7]  <- quantile(R_N,0.975)
  Post_Nasal_R0[k,8]  <- mean((1-exp(-Post_N))*100)
  Post_Nasal_R0[k,9]  <- quantile(r_N,0.025)
  Post_Nasal_R0[k,10] <- quantile(r_N,0.975)
  Post_Nasal_R0[k,11] <- mean(Post_N_IP)
  Post_Nasal_R0[k,12] <- quantile(IP_N,0.025)
  Post_Nasal_R0[k,13] <- quantile(IP_N,0.975)
  
  Post_Saliva_R0[k,2]  <- mean(Post_S)
  Post_Saliva_R0[k,3]  <- quantile(R0_S,0.025)
  Post_Saliva_R0[k,4]  <- quantile(R0_S,0.975)
  Post_Saliva_R0[k,5]  <- mean((Post-Post_S)/Post*100)
  Post_Saliva_R0[k,6]  <- quantile(R_S,0.025)
  Post_Saliva_R0[k,7]  <- quantile(R_S,0.975)
  Post_Saliva_R0[k,8]  <- mean((1-exp(-Post_S))*100)
  Post_Saliva_R0[k,9]  <- quantile(r_S,0.025)
  Post_Saliva_R0[k,10] <- quantile(r_S,0.975)
  Post_Saliva_R0[k,11] <- mean(Post_S_IP)
  Post_Saliva_R0[k,12] <- quantile(IP_S,0.025)
  Post_Saliva_R0[k,13] <- quantile(IP_S,0.975)
  
  Post_Effect_R0[k,2]  <- mean(R0_N - R0_S)
  Post_Effect_R0[k,3]  <- quantile(R0_N - R0_S,0.025)
  Post_Effect_R0[k,4]  <- quantile(R0_N - R0_S,0.975)
  Post_Effect_R0[k,5]  <- mean(R_N - R_S)
  Post_Effect_R0[k,6]  <- quantile(R_N - R_S,0.025)
  Post_Effect_R0[k,7]  <- quantile(R_N - R_S,0.975)
  Post_Effect_R0[k,8]  <- mean(r_N - r_S)
  Post_Effect_R0[k,9]  <- quantile(r_N - r_S,0.025)
  Post_Effect_R0[k,10] <- quantile(r_N - r_S,0.975)
  Post_Effect_R0[k,11]  <- mean(IP_N - IP_S)
  Post_Effect_R0[k,12]  <- quantile(IP_N - IP_S,0.025)
  Post_Effect_R0[k,13] <- quantile(IP_N - IP_S,0.975)
  Post_Effect_R0[k,14] <- t.test(R0_N - R0_S, alternative = "greater", mu = 0)$p.value
  Post_Effect_R0[k,15] <- t.test(R_N - R_S, alternative = "less", mu = 0)$p.value
  Post_Effect_R0[k,16] <- t.test(r_N - r_S, alternative = "greater", mu = 0)$p.value
  Post_Effect_R0[k,17] <- t.test(IP_N - IP_S, alternative = "greater", mu = 0)$p.value
  
}

Post_Nasal_R0 <- data.frame(Post_Nasal_R0)
Post_Saliva_R0 <- data.frame(Post_Saliva_R0)
Post_Effect_R0 <- data.frame(Post_Effect_R0)

colnames(Post_Nasal_R0)  <- c("R0","R","Rmin","Rmax","RT","RTmin","RTmax","r","rmin","rmax","IP","IPmin","IPmax")
colnames(Post_Saliva_R0) <- c("R0","R","Rmin","Rmax","RT","RTmin","RTmax","r","rmin","rmax","IP","IPmin","IPmax")
colnames(Post_Effect_R0) <- c("R0","R0D","R0Dmin","R0Dmax","RD","RDmin","RDmax","rD","rDmin","rDmax","IP","IPmin","IPmax","R0_test","R_test","r_test","IP_test")

write.csv(Post_Nasal_R0,"Post_Nasal_R0.csv", row.names = FALSE)
write.csv(Post_Saliva_R0,"Post_Saliva_R0.csv", row.names = FALSE)
write.csv(Post_Effect_R0,"Post_Effect_R0.csv", row.names = FALSE)

Post_Nasal_R0 <- read.csv("Post_Nasal_R0.csv")
Post_Saliva_R0 <- read.csv("Post_Saliva_R0.csv")
Post_Effect_R0 <- read.csv("Post_Effect_R0.csv")


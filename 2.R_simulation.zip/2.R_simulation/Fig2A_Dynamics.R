install.packages("deSolve")
install.packages("dplyr")

library(deSolve)
library(dplyr)


#################################################################################
#################################################################################
##################################### Model #####################################
#################################################################################
#################################################################################

setwd("~/Desktop/")
pop <- read.csv("populationParameters_Both.txt", row.names = 1)


##################################### Settings #####################################
Tmin <- 0
Tmax <- 30
step_size <- 0.01
mtime <- seq(Tmin,Tmax,step_size)


##################################### Viral dynamics model #####################################
Covfun<-function(pars){
  
  r <- as.numeric(pars[1])
  d <- as.numeric(pars[2])
  b <- as.numeric(pars[3])
  
  derivs<-function(time,y,pars){
    with(as.list(c(pars,y)),{
      
      dTa<--b*Ta*V
      dV<-r*Ta*V-d*V
      
      return(list(c(dTa,dV)))
    })
  }
  y<-c(Ta=1,V=0.01)
  
  times<-c(seq(Tmin,Tmax,step_size))
  out<-lsoda(y=y,parms=pars,times=times,func=derivs,rtol=0.00004,atol=0)
  out2<-cbind(time=out[,1],V=((log10(out[,3]))))
  as.data.frame(out2)
}




#################################################################################
#################################################################################
##################################### Nasal #####################################
#################################################################################
#################################################################################

par1 <- c(r=pop$value[1],d=pop$value[2],b=pop$value[3])
Fit1 <- Covfun(par1)
N <- nrow(pop0)
P1 <- matrix(NA,nrow=length(mtime),ncol=N)

for ( i in 1:N ) {
  
  pars <- c(r=pop0$r1_pop[i],d=pop0$d1_pop[i],b=pop0$b1_pop[i])
  out <- Covfun(pars)
  
  P1[,i] <- out$V
  
}

Min1 <- apply(P1,1,function(x){quantile(x,0.025)})
Max1 <- apply(P1,1,function(x){quantile(x,0.975)})

Fit1 <- cbind(Fit1,Min1,Max1)
Fit1$Min1[Fit1$Max1< 0] <- 0
Fit1$Min1[Fit1$Min1< 0] <- 0



##################################################################################
##################################################################################
##################################### Saliva #####################################
##################################################################################
##################################################################################

par2 <- c(r=pop$value[1+3],d=pop$value[2+3],b=pop$value[3+3])
Fit2 <- Covfun(par2)
N <- nrow(pop0)
P2 <- matrix(NA,nrow=length(mtime),ncol=N)

for ( i in 1:N ) {
  
  pars <- c(r=pop0$r2_pop[i],d=pop0$d2_pop[i],b=pop0$b2_pop[i])
  out <- Covfun(pars)
  
  P2[,i] <- out$V
  
}

Min2 <- apply(P2,1,function(x){quantile(x,0.025)})
Max2 <- apply(P2,1,function(x){quantile(x,0.975)})

Fit2 <- cbind(Fit2,Min2,Max2)
Fit2$Min2[Fit2$Max2< 0] <- 0
Fit2$Min2[Fit2$Min2< 0] <- 0



############################################################################################
############################################################################################
##################################### Characterization #####################################
############################################################################################
############################################################################################

Tmin <- 0
Tmax <- 100
step_size <- 0.01
mtime <- seq(Tmin,Tmax,step_size)


##################################### Viral dynamics model 
Covfun<-function(pars){
  
  r <- as.numeric(pars[1])
  d <- as.numeric(pars[2])
  b <- as.numeric(pars[3])
  
  derivs<-function(time,y,pars){
    with(as.list(c(pars,y)),{
      
      dTa<--b*Ta*V
      dV<-r*Ta*V-d*V
      
      return(list(c(dTa,dV)))
    })
  }
  y<-c(Ta=1,V=0.01)
  
  times<-c(seq(Tmin,Tmax,step_size))
  out<-lsoda(y=y,parms=pars,times=times,func=derivs,rtol=0.00004,atol=0)
  out2<-cbind(time=out[,1],V=((log10(out[,3]))))
  as.data.frame(out2)
}



##################################### Load data 
fitall<-read.table("estimatedIndividualParameters_Both.txt", sep = ",", comment.char = "", header = T)
L <- length(fitall$id)



##################################### Computation 
PT0 <- matrix(NA,nrow=L,ncol=2)
PV0 <- matrix(NA,nrow=L,ncol=2)
VS0 <- matrix(NA,nrow=L,ncol=2)
DV0 <- matrix(NA,nrow=L,ncol=2)

for (i in 1:L) {
  
  pars1 <- c(r=fitall$r1_mode[i],d=fitall$d1_mode[i],b=fitall$b1_mode[i])
  pars2 <- c(r=fitall$r2_mode[i],d=fitall$d2_mode[i],b=fitall$b2_mode[i])
  
  fit1 <- Covfun(pars1)
  fit2 <- Covfun(pars2)
  
  fit1$time <- round(fit1$time, digits=2) 
  fit2$time <- round(fit2$time, digits=2) 
  
  ###### 1) Peak timing
  PT0[i,1] <- fit1$time[which.max(fit1$V)]
  PT0[i,2] <- fit2$time[which.max(fit2$V)]
  
  ###### 2) Peak VL
  PV0[i,1] <- max(fit1$V)
  PV0[i,2] <- max(fit2$V)
  
  ###### 3) VL at symptom onset
  VS0[i,1] <- fit1$V[which(fit1$time==round(fitall$tau_mode[i],digits=2))]
  VS0[i,2] <- fit2$V[which(fit2$time==round(fitall$tau_mode[i],digits=2))]
  
  ###### 4) Duration of viral shedding ( ~ 1 copy/ml)
  fitt1 <- subset(fit1,fit1$V >= 0)
  fitt2 <- subset(fit2,fit2$V >= 0)
  
  DV0[i,1] <- max(fitt1$time)
  DV0[i,2] <- max(fitt2$time)
  
}

PT <- data.frame(value=c(PT0[,1],PT0[,2]), type=rep(c("N","S"),each=L))
PV <- data.frame(value=c(PV0[,1],PV0[,2]), type=rep(c("N","S"),each=L))
VS <- data.frame(value=c(VS0[,1],VS0[,2]), type=rep(c("N","S"),each=L))
DV <- data.frame(value=c(DV0[,1],DV0[,2]), type=rep(c("N","S"),each=L))


PTN <- subset(PT,PT$type=="N")
PTS <- subset(PT,PT$type=="S")
wilcox.test(PTN$value,PTS$value)
mean(PTN$value); quantile(PTN$value,c(0.025,0.975))
mean(PTS$value); quantile(PTS$value,c(0.025,0.975))


PVN <- subset(PV,PV$type=="N")
PVS <- subset(PV,PV$type=="S")
wilcox.test(PVN$value,PVS$value)
mean(PVN$value); quantile(PVN$value,c(0.025,0.975))
mean(PVS$value); quantile(PVS$value,c(0.025,0.975))


VSN <- subset(VS,VS$type=="N")
VSS <- subset(VS,VS$type=="S")
wilcox.test(VSN$value,VSS$value)
mean(VSN$value); quantile(VSN$value,c(0.025,0.975))
mean(VSS$value); quantile(VSS$value,c(0.025,0.975))


DVN <- subset(DV,DV$type=="N")
DVS <- subset(DV,DV$type=="S")
wilcox.test(DVN$value,DVS$value)
mean(DVN$value); quantile(DVN$value,c(0.025,0.975))
mean(DVS$value); quantile(DVS$value,c(0.025,0.975))




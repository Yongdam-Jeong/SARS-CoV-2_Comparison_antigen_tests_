install.packages("deSolve")
install.packages("dplyr")
install.packages("bayestestR")
install.packages("psych")

library(deSolve)
library(dplyr)
library(bayestestR) 
library(psych)

set.seed(456)

setwd("~/Desktop/")


#########################################################################################
######################################## Setting ########################################
#########################################################################################
Tmin <- 0
Tmax <- 60
step_size <- 1
mtime <- seq(Tmin,Tmax,step_size)
N <- 10^4 ## # of samples

DLmin <- 2
DLmax <- 7
Step_size <- 0.1

SI <- 6 ## Serial interval

pop <- read.csv("populationParameters_Both.txt", row.names = 1)
All <- read.csv("VL.csv")




########################################################################################################################
##################################### Computing scaling constant of infectiousness #####################################
########################################################################################################################
h <- 0.5471
Km <- 2.72*10^8
R <- 3.0
All$IF <- ((10^(All$V1*h)/(10^(All$V1*h)+Km^h))) + ((10^(All$V2*h)/(10^(All$V2*h)+Km^h)))

Rall <- c()
for (i in 1:N) {
  
  all <- subset(All,All$ID==i)
  Rall[i] <- auc(all$time,all$IF)
  
}
C <- R/mean(Rall)




#####################################################################################
##################################### Schematic #####################################
#####################################################################################
tmin <- 0
tmax <- 20
step_size <- 0.01
ttime <- seq(tmin,tmax,step_size)

Covfun<-function(pars){
  
  r <- as.numeric(pars[1])
  d <- as.numeric(pars[2])
  b <- as.numeric(pars[3])
  
  derivs<-function(time,y,pars){
    with(as.list(c(pars,y)),{
      
      dTa<--b*Ta*V
      dV<-r*Ta*V-d*V
      
      return(list(c(dTa,dV)))
    })
  }
  y<-c(Ta=1,V=0.01)
  
  times<-c(seq(tmin,tmax,step_size))
  out<-lsoda(y=y,parms=pars,times=times,func=derivs,rtol=0.00004,atol=0)
  out2<-cbind(time=out[,1],V=((log10(out[,3]))))
  as.data.frame(out2)
}

pop <- read.csv("populationParameters_Both.txt", row.names = 1)


##################### Infectiousness
####### Nasal
par1 <- c(r=pop$value[1],delta=pop$value[2],beta=pop$value[3])
Fit1 <- Covfun(par1)

####### Saliva
par2 <- c(r=pop$value[1+3],delta=pop$value[2+3],beta=pop$value[3+3])
Fit2 <- Covfun(par2)

FitI <- data.frame(time=ttime,nasal=Fit1$V,saliva=Fit2$V)

Infectiousness <- C* ((10^(FitI$nasal*h)/(10^(FitI$nasal*h)+Km^h)) + (10^(FitI$saliva*h)/(10^(FitI$saliva*h)+Km^h)))
FitI <- cbind(FitI,Infectiousness)

tinc <- round(pop$value[7], digits=0)
FitI$time <- round(FitI$time, digits=2)

FitIpost <- subset(FitI,FitI$time>=tinc)
FitIpost1 <- subset(FitI,FitI$time>=tinc+1)
FitIpost2 <- subset(FitI,FitI$time>=tinc+2)
FitIpost3 <- subset(FitI,FitI$time>=tinc+3)
FitIpost4 <- subset(FitI,FitI$time>=tinc+4)
FitIpost5 <- subset(FitI,FitI$time>=tinc+5)


##################### Risk of transmission after ending isolation
smin <- min(FitIpost$time)
smax <- max(FitIpost$time)
stime <- seq(smin,smax,step_size)

r <- c()
for (s in 1:length(stime)) {
  
  t <- smin + (s-1)*(step_size)
  fit <- subset(FitIpost,FitIpost$time>=t)
  R0 <- C*auc(fit$time,fit$Infectiousness)
  r[s] <- (1-exp(-R0))*100
  
}
FitIpost$risk <- r




##########################################################################################################################
##################################### Ending isolation in the post-symptomatic phase #####################################
##########################################################################################################################
TotalIF <- c()
TotalIF_Nasal <- c()
TotalIF_Saliva <- c()
TotalIF_Full <- c()

Isolation_Nasal <- c()
Isolation_Saliva <- c()

DL <- 6

All$P1 <- pnorm(DL,mean=All$V1, sd=pop["a1", "value"], lower.tail=FALSE)
All$P2 <- pnorm(DL,mean=All$V2, sd=pop["a2", "value"], lower.tail=FALSE)

for ( i in 1:N ) {
  
  all <- subset(All,All$ID==i)
  all <- subset(all,all$time>=all$IP[1])
  R0  <- C*auc(all$time,all$IF)
  
  ####### Infectiousness for each time (time >= 2)
  all2 <- subset(all,all$time>=all$IP[1]+2)
  all3 <- subset(all,all$time>=all$IP[1]+3)
  all4 <- subset(all,all$time>=all$IP[1]+4)
  all5 <- subset(all,all$time>=all$IP[1]+5)
  # all6 <- subset(all,all$time>=all$IP[1]+6)
  # all7 <- subset(all,all$time>=all$IP[1]+7)
  # all8 <- subset(all,all$time>=all$IP[1]+8)
  # all9 <- subset(all,all$time>=all$IP[1]+9)
  # all10 <- subset(all,all$time>=all$IP[1]+10)
  
  R02 <- C*auc(all2$time,all2$IF)
  R03 <- C*auc(all3$time,all3$IF)
  R04 <- C*auc(all4$time,all4$IF)
  R05 <- C*auc(all5$time,all5$IF)
  # R06 <- C*auc(all6$time,all6$IF)
  # R07 <- C*auc(all7$time,all7$IF)
  # R08 <- C*auc(all8$time,all8$IF)
  # R09 <- C*auc(all9$time,all9$IF)
  # R010 <- C*auc(all10$time,all10$IF)
  
  
  ####### Probability of detection for each time since symptom onset
  ## Nasal
  p0_1 <- 1
  p1_1 <- all$P1[all$time==all$IP[1]+1]
  p2_1 <- all$P1[all$time==all$IP[1]+2]
  p3_1 <- all$P1[all$time==all$IP[1]+3]
  p4_1 <- all$P1[all$time==all$IP[1]+4]
  # p5_1 <- all$P1[all$time==all$IP[1]+5]
  # p6_1 <- all$P1[all$time==all$IP[1]+6]
  # p7_1 <- all$P1[all$time==all$IP[1]+7]
  # p8_1 <- all$P1[all$time==all$IP[1]+8]
  # p9_1 <- all$P1[all$time==all$IP[1]+9]
  # p10_1 <- all$P1[all$time==all$IP[1]+10]
  
  ## Saliva
  p0_2 <- 1
  p1_2 <- all$P2[all$time==all$IP[1]+1]
  p2_2 <- all$P2[all$time==all$IP[1]+2]
  p3_2 <- all$P2[all$time==all$IP[1]+3]
  p4_2 <- all$P2[all$time==all$IP[1]+4]
  # p5_2 <- all$P2[all$time==all$IP[1]+5]
  # p6_2 <- all$P2[all$time==all$IP[1]+6]
  # p7_2 <- all$P2[all$time==all$IP[1]+7]
  # p8_2 <- all$P2[all$time==all$IP[1]+8]
  # p9_2 <- all$P2[all$time==all$IP[1]+9]
  # p10_2 <- all$P2[all$time==all$IP[1]+10]
    
  
  ####### Coefficients of probability for each infectiousness (time >= 2)
  ## Nasal
  C2_1 <- p0_1*(1-p1_1)*(1-p2_1) 
  C3_1 <- p0_1*p1_1*(1-p2_1)*(1-p3_1)
  C4_1 <- p0_1*(1)*p2_1*(1-p3_1)*(1-p4_1)
  
  
  ## Saliva
  C2_2 <- p0_2*(1-p1_2)*(1-p2_2) 
  C3_2 <- p0_2*p1_2*(1-p2_2)*(1-p3_2)
  C4_2 <- p0_2*(1)*p2_2*(1-p3_2)*(1-p4_2)
  
  TotalIF[i] <- R0
  TotalIF_Nasal[i]  <- (C2_1*R02 + C3_1*R03 + C4_1*R04) + (p0_1 - (C2_1+C3_1+C4_1))*R05
  TotalIF_Saliva[i] <- (C2_2*R02 + C3_2*R03 + C4_2*R04) + (p0_2 - (C2_2+C3_2+C4_2))*R05
  TotalIF_Full[i] <- R05
  
  Isolation_Nasal[i]  <- 2*(C2_1) + 3*(C3_1) + 4*(C4_1) + 5*(p0_1 - (C2_1+C3_1+C4_1))
  Isolation_Saliva[i] <- 2*(C2_2) + 3*(C3_2) + 4*(C4_2) + 5*(p0_2 - (C2_2+C3_2+C4_2))
  
}

TotalIF <- data.frame(value=TotalIF,group=rep(0,times=N))
TotalIF_Nasal <- data.frame(value=TotalIF_Nasal,group=rep(1,times=N))
TotalIF_Saliva <- data.frame(value=TotalIF_Saliva,group=rep(2,times=N))
TotalIF_Full <- data.frame(value=TotalIF_Full,group=rep(0,times=N))

Isolation_Nasal <- data.frame(value=Isolation_Nasal,group=rep(1,times=N))
Isolation_Saliva <- data.frame(value=Isolation_Saliva,group=rep(2,times=N))

######### 1) Reproduction number
Post <- data.frame(R0=TotalIF$value,
                   R1=TotalIF_Nasal$value,
                   R2=TotalIF_Saliva$value,
                   R5=TotalIF_Full$value,
                   I1=Isolation_Nasal$value,
                   I2=Isolation_Saliva$value,
                   ID=seq(1,N,by=1))
# write.csv(Post,"Post.csv",row.names = FALSE)
Post <- read.csv("Post.csv")

Number <- data.frame(value=c(Post$R0,Post$R1,Post$R2,Post$R5),
                     group=rep(c("0","1","2","5"),each=N))

describeBy(Number$value,Number$group)
bartlett.test(Number$value,Number$group)
summary(aov(Number$value~Number$group))

Number_0 <- subset(Number,group==0)
Number_1 <- subset(Number,group==1)
Number_2 <- subset(Number,group==2)
Number_5 <- subset(Number,group==5)

t.test(Number_0$value - 1, alternative = "less", mu = 0)$p.value
t.test(Number_1$value - 1, alternative = "less", mu = 0)$p.value
t.test(Number_2$value - 1, alternative = "less", mu = 0)$p.value
t.test(Number_5$value - 1, alternative = "less", mu = 0)$p.value

P0 <- length(which(Number_0$value<=1))/N
P0 - 1.96*sqrt(P0*(1-P0)/N)
P0 + 1.96*sqrt(P0*(1-P0)/N)

P1 <- length(which(Number_1$value<=1))/N
P1 - 1.96*sqrt(P1*(1-P1)/N)
P1 + 1.96*sqrt(P1*(1-P1)/N)

P2 <- length(which(Number_2$value<=1))/N
P2 - 1.96*sqrt(P2*(1-P2)/N)
P2 + 1.96*sqrt(P2*(1-P2)/N)

P5 <- length(which(Number_5$value<=1))/N
P5 - 1.96*sqrt(P5*(1-P5)/N)
P5 + 1.96*sqrt(P5*(1-P5)/N)

######## 2) Reduction of transmissibility
Reduction <- data.frame(value=c((Post$R0-Post$R1)/Post$R0*100,(Post$R0-Post$R2)/Post$R0*100,(Post$R0-Post$R5)/Post$R0*100),
                        group=rep(c("1","2","5"),each=N))


######## 3) Risk of transmission
Risk <- data.frame(value=c((1-exp(-Post$R0))*100,(1-exp(-Post$R1))*100,(1-exp(-Post$R2))*100,(1-exp(-Post$R5))*100),
                   group=rep(c("0","1","2","5"),each=N))

describeBy(Risk$value,Risk$group)
bartlett.test(Risk$value,Risk$group)
summary(aov(Risk$value~Risk$group))

Risk_0 <- subset(Risk,group==0)
Risk_1 <- subset(Risk,group==1)
Risk_2 <- subset(Risk,group==2)
Risk_5 <- subset(Risk,group==5)

mean(Risk_1$value - Risk_2$value); quantile(Risk_1$value - Risk_2$value, c(0.025,0.975))
L <- length(which(Risk_1$value - Risk_2$value>0))/N
L - 1.96*sqrt(L*(1-L)/N)
L + 1.96*sqrt(L*(1-L)/N)
t.test(Risk_1$value - Risk_2$value, alternative = "greater", mu = 0)$p.value




########################################################################################################################
##################################### Additional required period with limited risk #####################################
########################################################################################################################

lr <- 10 ## limited risk for additional period
D <- Tmax - max(All$IP)
D <- D - D%%10

IPLR <- c() ## Isolation Period with Limited Risk (lr)
for ( i in 1:N ) {
  
  all <- subset(All,All$ID==i)
  all <- subset(all,all$time>=all$IP[1])
  
  risk <- c()
  for (k in 1:D) {
    
    allr <- subset(all,all$time>=all$IP[1]+(k-1))
    R0 <- C*auc(allr$time,allr$IF)
    risk[k] <- (1-exp(-R0))*100
    
  }
  
  IPLR[i] <- min(which(risk<=lr)) - 1
  
}

Post$A1 <- IPLR - Post$I1
Post$A2 <- IPLR - Post$I2

# Post$A1 <- relu(IPLR - Post$I1)
# Post$A2 <- relu(IPLR - Post$I2)
# 
# Post$A1[Post$r1<lr] <- 0
# Post$A2[Post$r2<lr] <- 0

mean(Post$A1); quantile(Post$A1,c(0.025,0.975))
mean(Post$A2); quantile(Post$A2,c(0.025,0.975))

length(which(Post$A1>0))/N*100
length(which(Post$A2>0))/N*100


######## 4) Mean isolation period
Isolation <- data.frame(value=c(Post$I1,Post$I2),
                        risk=c((1-exp(-Post$R1))*100,(1-exp(-Post$R2))*100),
                        group=rep(c("1","2"),each=N))

######## 5) Additional required period with limited risk
Additional <- data.frame(value=c(Post$A1,Post$A2),group=rep(c("1","2"),each=N))
# Additional <- subset(Additional,value>0)

# additional <- subset(Additional,value>0)
additional1 <- subset(Additional,group=="1")
additional2 <- subset(Additional,group=="2")
mean(additional1$value); quantile(additional1$value,c(0.025,0.975))
mean(additional2$value); quantile(additional2$value,c(0.025,0.975))




###########################################################################################
##################################### Detection limit #####################################
###########################################################################################
Post_Nasal  <- matrix(NA,nrow=((DLmax-DLmin)/Step_size+1),ncol=11)
Post_Saliva <- matrix(NA,nrow=((DLmax-DLmin)/Step_size+1),ncol=11)
Post_Effect_0N <- matrix(NA,nrow=((DLmax-DLmin)/Step_size+1),ncol=13)
Post_Effect_0S <- matrix(NA,nrow=((DLmax-DLmin)/Step_size+1),ncol=13)
Post_Effect_NS <- matrix(NA,nrow=((DLmax-DLmin)/Step_size+1),ncol=13)
Post_Full <- matrix(NA,nrow=((DLmax-DLmin)/Step_size+1),ncol=10)

for ( k in 1:((DLmax-DLmin)/Step_size+1) ) {
  

  ##################################### Probability of positive results
  
  DL <- DLmin + (k-1)*Step_size
  
  All$P1 <- pnorm(DL,mean=All$V1, sd=pop["a1", "value"], lower.tail=FALSE)
  All$P2 <- pnorm(DL,mean=All$V2, sd=pop["a2", "value"], lower.tail=FALSE)
  
  
  ##################################### Ending isolation by test
  
  Post_N <- c()
  Post_S <- c()
  Post_F <- c()
  
  for ( i in 1:N ) {
    
    all <- subset(All,All$ID==i)
    all <- subset(all,all$time>=all$IP[1])
    R0  <- C*auc(all$time,all$IF)
    
    ####### Infectiousness for each time (time >= 2)
    all2 <- subset(all,all$time>=all$IP[1]+2)
    all3 <- subset(all,all$time>=all$IP[1]+3)
    all4 <- subset(all,all$time>=all$IP[1]+4)
    all5 <- subset(all,all$time>=all$IP[1]+5)
    # all6 <- subset(all,all$time>=all$IP[1]+6)
    # all7 <- subset(all,all$time>=all$IP[1]+7)
    # all8 <- subset(all,all$time>=all$IP[1]+8)
    # all9 <- subset(all,all$time>=all$IP[1]+9)
    # all10 <- subset(all,all$time>=all$IP[1]+10)
    
    R02 <- C*auc(all2$time,all2$IF)
    R03 <- C*auc(all3$time,all3$IF)
    R04 <- C*auc(all4$time,all4$IF)
    R05 <- C*auc(all5$time,all5$IF)
    # R06 <- C*auc(all6$time,all6$IF)
    # R07 <- C*auc(all7$time,all7$IF)
    # R08 <- C*auc(all8$time,all8$IF)
    # R09 <- C*auc(all9$time,all9$IF)
    # R010 <- C*auc(all10$time,all10$IF)
    
    
    ####### Probability of detection for each time since symptom onset
    ## Nasal
    p0_1 <- 1
    p1_1 <- all$P1[all$time==all$IP[1]+1]
    p2_1 <- all$P1[all$time==all$IP[1]+2]
    p3_1 <- all$P1[all$time==all$IP[1]+3]
    p4_1 <- all$P1[all$time==all$IP[1]+4]
    # p5_1 <- all$P1[all$time==all$IP[1]+5]
    # p6_1 <- all$P1[all$time==all$IP[1]+6]
    # p7_1 <- all$P1[all$time==all$IP[1]+7]
    # p8_1 <- all$P1[all$time==all$IP[1]+8]
    # p9_1 <- all$P1[all$time==all$IP[1]+9]
    # p10_1 <- all$P1[all$time==all$IP[1]+10]
    
    ## Saliva
    p0_2 <- 1
    p1_2 <- all$P2[all$time==all$IP[1]+1]
    p2_2 <- all$P2[all$time==all$IP[1]+2]
    p3_2 <- all$P2[all$time==all$IP[1]+3]
    p4_2 <- all$P2[all$time==all$IP[1]+4]
    # p5_2 <- all$P2[all$time==all$IP[1]+5]
    # p6_2 <- all$P2[all$time==all$IP[1]+6]
    # p7_2 <- all$P2[all$time==all$IP[1]+7]
    # p8_2 <- all$P2[all$time==all$IP[1]+8]
    # p9_2 <- all$P2[all$time==all$IP[1]+9]
    # p10_2 <- all$P2[all$time==all$IP[1]+10]
    
    
    ####### Coefficients of probability for each infectiousness (time >= 2)
    ## Nasal
    C2_1 <- p0_1*(1-p1_1)*(1-p2_1) 
    C3_1 <- p0_1*p1_1*(1-p2_1)*(1-p3_1)
    C4_1 <- p0_1*(1)*p2_1*(1-p3_1)*(1-p4_1)
    # C5_1 <- (p0_1 - 
    #          p0_1*(1-p1_1)*(1-p2_1)) * p3_1*(1-p4_1)*(1-p5_1)
    # C6_1 <- (p0_1 - 
    #          p0_1*(1-p1_1)*(1-p2_1) - 
    #          p0_1*p1_1*(1-p2_1)*(1-p3_1)) * p4_1*(1-p5_1)*(1-p6_1)
    # C7_1 <- (p0_1 - 
    #          p0_1*(1-p1_1)*(1-p2_1) - 
    #          p0_1*p1_1*(1-p2_1)*(1-p3_1) -
    #          p0_1*p1_1*p2_1*(1-p3_1)*(1-p4_1)) * p5_1*(1-p6_1)*(1-p7_1)
    # C8_1 <- (p0_1 - 
    #          p0_1*(1-p1_1)*(1-p2_1) - 
    #          p0_1*p1_1*(1-p2_1)*(1-p3_1) -
    #          p0_1*p1_1*p2_1*(1-p3_1)*(1-p4_1) -
    #          p0_1*p1_1*p2_1*p3_1*(1-p4_1)*(1-p5_1)) * p6_1*(1-p7_1)*(1-p8_1)
    # C9_1 <- (p0_1 - 
    #          p0_1*(1-p1_1)*(1-p2_1) - 
    #          p0_1*p1_1*(1-p2_1)*(1-p3_1) -
    #          p0_1*p1_1*p2_1*(1-p3_1)*(1-p4_1) -
    #          p0_1*p1_1*p2_1*p3_1*(1-p4_1)*(1-p5_1) -
    #          p0_1*p1_1*p2_1*p3_1*p4_1*(1-p5_1)*(1-p6_1)) * p7_1*(1-p8_1)*(1-p9_1)
    # C10_1 <-(p0_1 - 
    #          p0_1*(1-p1_1)*(1-p2_1) - 
    #          p0_1*p1_1*(1-p2_1)*(1-p3_1) -
    #          p0_1*p1_1*p2_1*(1-p3_1)*(1-p4_1) -
    #          p0_1*p1_1*p2_1*p3_1*(1-p4_1)*(1-p5_1) -
    #          p0_1*p1_1*p2_1*p3_1*p4_1*(1-p5_1)*(1-p6_1) -
    #          p0_1*p1_1*p2_1*p3_1*p4_1*p5_1*(1-p6_1)*(1-p7_1)) * p8_1*(1-p9_1)*(1-p10_1)
    
    ## Saliva
    C2_2 <- p0_2*(1-p1_2)*(1-p2_2) 
    C3_2 <- p0_2*p1_2*(1-p2_2)*(1-p3_2)
    C4_2 <- p0_2*(1)*p2_2*(1-p3_2)*(1-p4_2)
    # C5_2 <- (p0_2 -
    #            p0_2*(1-p1_2)*(1-p2_2)) * p3_2*(1-p4_2)*(1-p5_2)
    # C6_2 <- (p0_2 -
    #            p0_2*(1-p1_2)*(1-p2_2) -
    #            p0_2*p1_2*(1-p2_2)*(1-p3_2)) * p4_2*(1-p5_2)*(1-p6_2)
    # C7_2 <- (p0_2 -
    #            p0_2*(1-p1_2)*(1-p2_2) -
    #            p0_2*p1_2*(1-p2_2)*(1-p3_2) -
    #            p0_2*p1_2*p2_2*(1-p3_2)*(1-p4_2)) * p5_2*(1-p6_2)*(1-p7_2)
    # C8_2 <- (p0_2 -
    #            p0_2*(1-p1_2)*(1-p2_2) -
    #            p0_2*p1_2*(1-p2_2)*(1-p3_2) -
    #            p0_2*p1_2*p2_2*(1-p3_2)*(1-p4_2) -
    #            p0_2*p1_2*p2_2*p3_2*(1-p4_2)*(1-p5_2)) * p6_2*(1-p7_2)*(1-p8_2)
    # C9_2 <- (p0_2 -
    #            p0_2*(1-p1_2)*(1-p2_2) -
    #            p0_2*p1_2*(1-p2_2)*(1-p3_2) -
    #            p0_2*p1_2*p2_2*(1-p3_2)*(1-p4_2) -
    #            p0_2*p1_2*p2_2*p3_2*(1-p4_2)*(1-p5_2) -
    #            p0_2*p1_2*p2_2*p3_2*p4_2*(1-p5_2)*(1-p6_2)) * p7_2*(1-p8_2)*(1-p9_2)
    # C10_2 <-(p0_2 -
    #            p0_2*(1-p1_2)*(1-p2_2) -
    #            p0_2*p1_2*(1-p2_2)*(1-p3_2) -
    #            p0_2*p1_2*p2_2*(1-p3_2)*(1-p4_2) -
    #            p0_2*p1_2*p2_2*p3_2*(1-p4_2)*(1-p5_2) -
    #            p0_2*p1_2*p2_2*p3_2*p4_2*(1-p5_2)*(1-p6_2) -
    #            p0_2*p1_2*p2_2*p3_2*p4_2*p5_2*(1-p6_2)*(1-p7_2)) * p8_2*(1-p9_2)*(1-p10_2)
    
    Post_N[i] <- (C2_1*R02 + C3_1*R03 + C4_1*R04) + (p0_1 - (C2_1+C3_1+C4_1))*R05
    Post_S[i] <- (C2_2*R02 + C3_2*R03 + C4_2*R04) + (p0_2 - (C2_2+C3_2+C4_2))*R05
    Post_F[i] <- R05
   
  }
  
  Post_Nasal[k,1]  <- DL
  Post_Saliva[k,1] <- DL
  Post_Effect_0N[k,1] <- DL
  Post_Effect_0S[k,1] <- DL
  Post_Effect_NS[k,1] <- DL
  Post_Full[k,1] <- DL
  
  
  ########### Arranging
  Post_DL <- data.frame(R0=Post$R0,R1=Post_N,R2=Post_S,R5=Post_F,ID=seq(1,N,by=1))
  
  R0_0 <- c()
  R0_N <- c()
  R0_S <- c()
  R0_F <- c()
  
  R_0 <- c()
  R_N <- c()
  R_S <- c()
  R_F <- c()
  
  r_0 <- c() 
  r_N <- c() 
  r_S <- c()
  r_F <- c()
  
  for (l in 1:100) {
    
    # id <- sample(Post_DL$ID,100)
    # post <- subset(Post_DL,Post_DL$ID %in% id)
    
    post <- Post_DL[sample(nrow(Post_DL), size = 10000, replace = TRUE), ]
    row.names(post) <- NULL
    
    R0_0[l] <- mean(post$R0)
    R0_N[l] <- mean(post$R1)
    R0_S[l] <- mean(post$R2)
    R0_F[l] <- mean(post$R5)
    
    R_0[l] <- mean((post$R0-post$R0)/post$R0*100)
    R_N[l] <- mean((post$R0-post$R1)/post$R0*100)
    R_S[l] <- mean((post$R0-post$R2)/post$R0*100)
    R_F[l] <- mean((post$R0-post$R5)/post$R0*100)
    
    r_0[l] <- mean((1-exp(-post$R0))*100)
    r_N[l] <- mean((1-exp(-post$R1))*100)
    r_S[l] <- mean((1-exp(-post$R2))*100)
    r_F[l] <- mean((1-exp(-post$R5))*100)
    
  }
  
  Post_Nasal[k,2]  <- mean(Post_N)
  Post_Nasal[k,3]  <- quantile(R0_N,0.025)
  Post_Nasal[k,4]  <- quantile(R0_N,0.975)
  Post_Nasal[k,5]  <- mean((Post$R0-Post_N)/Post$R0*100)
  Post_Nasal[k,6]  <- quantile(R_N,0.025)
  Post_Nasal[k,7]  <- quantile(R_N,0.975)
  Post_Nasal[k,8]  <- mean((1-exp(-Post_N))*100)
  Post_Nasal[k,9]  <- quantile(r_N,0.025)
  Post_Nasal[k,10] <- quantile(r_N,0.975)
  Post_Nasal[k,11] <- t.test(Post_N - 1, alternative = "less", mu = 0)$p.value
  
  Post_Saliva[k,2]  <- mean(Post_S)
  Post_Saliva[k,3]  <- quantile(R0_S,0.025)
  Post_Saliva[k,4]  <- quantile(R0_S,0.975)
  Post_Saliva[k,5]  <- mean((Post$R0-Post_S)/Post$R0*100)
  Post_Saliva[k,6]  <- quantile(R_S,0.025)
  Post_Saliva[k,7]  <- quantile(R_S,0.975)
  Post_Saliva[k,8]  <- mean((1-exp(-Post_S))*100)
  Post_Saliva[k,9]  <- quantile(r_S,0.025)
  Post_Saliva[k,10] <- quantile(r_S,0.975)
  Post_Saliva[k,11] <- t.test(Post_S - 1, alternative = "less", mu = 0)$p.value
  
  Post_Effect_0N[k,2]  <- mean(R0_0 - R0_N)
  Post_Effect_0N[k,3]  <- quantile(R0_0 - R0_N,0.025)
  Post_Effect_0N[k,4]  <- quantile(R0_0 - R0_N,0.975)
  Post_Effect_0N[k,5]  <- mean(R_0 - R_N)
  Post_Effect_0N[k,6]  <- quantile(R_0 - R_N,0.025)
  Post_Effect_0N[k,7]  <- quantile(R_0 - R_N,0.975)
  Post_Effect_0N[k,8]  <- mean(r_0 - r_N)
  Post_Effect_0N[k,9]  <- quantile(r_0 - r_N,0.025)
  Post_Effect_0N[k,10] <- quantile(r_0 - r_N,0.975)
  Post_Effect_0N[k,11] <- t.test(R0_0 - R0_N, alternative = "greater", mu = 0)$p.value
  Post_Effect_0N[k,12] <- t.test(R_0 - R_N, alternative = "less", mu = 0)$p.value
  Post_Effect_0N[k,13] <- t.test(r_0 - r_N, alternative = "greater", mu = 0)$p.value
  
  Post_Effect_0S[k,2]  <- mean(R0_0 - R0_S)
  Post_Effect_0S[k,3]  <- quantile(R0_0 - R0_S,0.025)
  Post_Effect_0S[k,4]  <- quantile(R0_0 - R0_S,0.975)
  Post_Effect_0S[k,5]  <- mean(R_0 - R_S)
  Post_Effect_0S[k,6]  <- quantile(R_0 - R_S,0.025)
  Post_Effect_0S[k,7]  <- quantile(R_0 - R_S,0.975)
  Post_Effect_0S[k,8]  <- mean(r_0 - r_S)
  Post_Effect_0S[k,9]  <- quantile(r_0 - r_S,0.025)
  Post_Effect_0S[k,10] <- quantile(r_0 - r_S,0.975)
  Post_Effect_0S[k,11] <- t.test(R0_0 - R0_S, alternative = "greater", mu = 0)$p.value
  Post_Effect_0S[k,12] <- t.test(R_0 - R_S, alternative = "less", mu = 0)$p.value
  Post_Effect_0S[k,13] <- t.test(r_0 - r_S, alternative = "greater", mu = 0)$p.value
  
  Post_Effect_NS[k,2]  <- mean(R0_N - R0_S)
  Post_Effect_NS[k,3]  <- quantile(R0_N - R0_S,0.025)
  Post_Effect_NS[k,4]  <- quantile(R0_N - R0_S,0.975)
  Post_Effect_NS[k,5]  <- mean(R_N - R_S)
  Post_Effect_NS[k,6]  <- quantile(R_N - R_S,0.025)
  Post_Effect_NS[k,7]  <- quantile(R_N - R_S,0.975)
  Post_Effect_NS[k,8]  <- mean(r_N - r_S)
  Post_Effect_NS[k,9]  <- quantile(r_N - r_S,0.025)
  Post_Effect_NS[k,10] <- quantile(r_N - r_S,0.975)
  Post_Effect_NS[k,11] <- t.test(R0_N - R0_S, alternative = "greater", mu = 0)$p.value
  Post_Effect_NS[k,12] <- t.test(R_N - R_S, alternative = "less", mu = 0)$p.value
  Post_Effect_NS[k,13] <- t.test(r_N - r_S, alternative = "greater", mu = 0)$p.value
  
  Post_Full[k,2]  <- mean(Post_F)
  Post_Full[k,3]  <- quantile(R0_F,0.025)
  Post_Full[k,4]  <- quantile(R0_F,0.975)
  Post_Full[k,5]  <- mean((Post$R0-Post_F)/Post$R0*100)
  Post_Full[k,6]  <- quantile(R_F,0.025)
  Post_Full[k,7]  <- quantile(R_F,0.975)
  Post_Full[k,8]  <- mean((1-exp(-Post_F))*100)
  Post_Full[k,9]  <- quantile(r_F,0.025)
  Post_Full[k,10] <- quantile(r_F,0.975)
  
}

Post_Nasal <- data.frame(Post_Nasal)
Post_Saliva <- data.frame(Post_Saliva)
Post_Effect_0N <- data.frame(Post_Effect_0N)
Post_Effect_0S <- data.frame(Post_Effect_0S)
Post_Effect_NS <- data.frame(Post_Effect_NS)
Post_Full <- data.frame(Post_Full)

colnames(Post_Nasal)  <- c("DL","R","Rmin","Rmax","RT","RTmin","RTmax","r","rmin","rmax","unity")
colnames(Post_Saliva) <- c("DL","R","Rmin","Rmax","RT","RTmin","RTmax","r","rmin","rmax","unity")
colnames(Post_Effect_0N) <- c("DL","R0D","R0Dmin","R0Dmax","RD","RDmin","RDmax","rD","rDmin","rDmax","R0_test","R_test","r_test")
colnames(Post_Effect_0S) <- c("DL","R0D","R0Dmin","R0Dmax","RD","RDmin","RDmax","rD","rDmin","rDmax","R0_test","R_test","r_test")
colnames(Post_Effect_NS) <- c("DL","R0D","R0Dmin","R0Dmax","RD","RDmin","RDmax","rD","rDmin","rDmax","R0_test","R_test","r_test")
colnames(Post_Full) <- c("DL","R","Rmin","Rmax","RT","RTmin","RTmax","r","rmin","rmax")

write.csv(Post_Nasal,"Post_Nasal.csv", row.names = FALSE)
write.csv(Post_Saliva,"Post_Saliva.csv", row.names = FALSE)
write.csv(Post_Effect_0N,"Post_Effect_0N.csv", row.names = FALSE)
write.csv(Post_Effect_0S,"Post_Effect_0S.csv", row.names = FALSE)
write.csv(Post_Effect_NS,"Post_Effect_NS.csv", row.names = FALSE)
write.csv(Post_Full,"Post_Full.csv", row.names = FALSE)

Post_Nasal <- read.csv("Post_Nasal.csv")
Post_Saliva <- read.csv("Post_Saliva.csv")
Post_Effect_0N <- read.csv("Post_Effect_0N.csv")
Post_Effect_0S <- read.csv("Post_Effect_0S.csv")
Post_Effect_NS <- read.csv("Post_Effect_NS.csv")
Post_Full <- read.csv("Post_Full.csv")


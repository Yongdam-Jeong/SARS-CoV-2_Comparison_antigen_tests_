

setwd("~/Desktop/")


#########################################################################################################
######################################## Negative binomial model ########################################
#########################################################################################################

N <- 10000

k <- 0.41 ## Baseline


######################################## 1) Pre-symptomatic
Pre <- read.csv("Pre.csv")

Pre$R0P <- 1 - exp(-Pre$R0)
Pre$R1P <- 1 - exp(-Pre$R1)
Pre$R2P <- 1 - exp(-Pre$R2)

Pre$R0N <- 1 - (1+Pre$R0/k)^(-k)
Pre$R1N <- 1 - (1+Pre$R1/k)^(-k)
Pre$R2N <- 1 - (1+Pre$R2/k)^(-k)

Pre_0P <- data.frame(value=c(Pre$R0P,1-ppois(4-1,lambda=Pre$R0)), number=rep(c("1","4"),each=N), dist="P")
Pre_0N <- data.frame(value=c(Pre$R0N,1-pnbinom(4-1,size=k,mu=Pre$R0)), number=rep(c("1","4"),each=N), dist="N")
Pre_0 <- rbind(Pre_0P,Pre_0N)
Pre_0$dist <- factor(Pre_0$dist, levels=c("P","N"))

Pre_1P <- data.frame(value=c(Pre$R1P,1-ppois(4-1,lambda=Pre$R1)), number=rep(c("1","4"),each=N), dist="P")
Pre_1N <- data.frame(value=c(Pre$R1N,1-pnbinom(4-1,size=k,mu=Pre$R1)), number=rep(c("1","4"),each=N), dist="N")
Pre_1 <- rbind(Pre_1P,Pre_1N)
Pre_1$dist <- factor(Pre_1$dist, levels=c("P","N"))

Pre_2P <- data.frame(value=c(Pre$R2P,1-ppois(4-1,lambda=Pre$R2)), number=rep(c("1","4"),each=N), dist="P")
Pre_2N <- data.frame(value=c(Pre$R2N,1-pnbinom(4-1,size=k,mu=Pre$R2)), number=rep(c("1","4"),each=N), dist="N")
Pre_2 <- rbind(Pre_2P,Pre_2N)
Pre_2$dist <- factor(Pre_2$dist, levels=c("P","N"))


Pre_1P_1 <- subset(Pre_1P, number==1)
Pre_1P_4 <- subset(Pre_1P, number==4)

Pre_1N_1 <- subset(Pre_1N, number==1)
Pre_1N_4 <- subset(Pre_1N, number==4)

Pre_2P_1 <- subset(Pre_2P, number==1)
Pre_2P_4 <- subset(Pre_2P, number==4)

Pre_2N_1 <- subset(Pre_2N, number==1)
Pre_2N_4 <- subset(Pre_2N, number==4)

t.test(Pre_1N_1$value-Pre_2N_1$value, alternative = "greater", mu = 0)$p.value
t.test(Pre_1N_4$value-Pre_2N_4$value, alternative = "greater", mu = 0)$p.value



######################################## 2) Post-symptomatic
Post <- read.csv("Post.csv")

Post$R0P <- 1 - exp(-Post$R0)
Post$R1P <- 1 - exp(-Post$R1)
Post$R2P <- 1 - exp(-Post$R2)

Post$R0N <- 1 - (1+Post$R0/k)^(-k)
Post$R1N <- 1 - (1+Post$R1/k)^(-k)
Post$R2N <- 1 - (1+Post$R2/k)^(-k)

Post_0P <- data.frame(value=c(Post$R0P,1-ppois(4-1,lambda=Post$R0)), number=rep(c("1","4"),each=N), dist="P")
Post_0N <- data.frame(value=c(Post$R0N,1-pnbinom(4-1,size=k,mu=Post$R0)), number=rep(c("1","4"),each=N), dist="N")
Post_0 <- rbind(Post_0P,Post_0N)
Post_0$dist <- factor(Post_0$dist, levels=c("P","N"))

Post_1P <- data.frame(value=c(Post$R1P,1-ppois(4-1,lambda=Post$R1)), number=rep(c("1","4"),each=N), dist="P")
Post_1N <- data.frame(value=c(Post$R1N,1-pnbinom(4-1,size=k,mu=Post$R1)), number=rep(c("1","4"),each=N), dist="N")
Post_1 <- rbind(Post_1P,Post_1N)
Post_1$dist <- factor(Post_1$dist, levels=c("P","N"))

Post_2P <- data.frame(value=c(Post$R2P,1-ppois(4-1,lambda=Post$R2)), number=rep(c("1","4"),each=N), dist="P")
Post_2N <- data.frame(value=c(Post$R2N,1-pnbinom(4-1,size=k,mu=Post$R2)), number=rep(c("1","4"),each=N), dist="N")
Post_2 <- rbind(Post_2P,Post_2N)
Post_2$dist <- factor(Post_2$dist, levels=c("P","N"))


Post_1P_1 <- subset(Post_1P, number==1)
Post_1P_4 <- subset(Post_1P, number==4)

Post_1N_1 <- subset(Post_1N, number==1)
Post_1N_4 <- subset(Post_1N, number==4)

Post_2P_1 <- subset(Post_2P, number==1)
Post_2P_4 <- subset(Post_2P, number==4)

Post_2N_1 <- subset(Post_2N, number==1)
Post_2N_4 <- subset(Post_2N, number==4)

t.test(Post_1N_1$value-Post_2N_1$value, alternative = "greater", mu = 0)$p.value
t.test(Post_1N_4$value-Post_2N_4$value, alternative = "greater", mu = 0)$p.value

